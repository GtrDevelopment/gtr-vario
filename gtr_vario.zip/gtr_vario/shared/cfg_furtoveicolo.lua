FurtoVeh = {}

FurtoVeh.rprogress = true
FurtoVeh.voltlab = true

FurtoVeh.LSPD = 'police'
FurtoVeh.LSPDRischioBasso = 0
FurtoVeh.LSPDRischioMedio = 0
FurtoVeh.LSPDRischioAlto = 0

FurtoVeh.SoldiSporchi = true

FurtoVeh.AttrezzoPerScassinare = "lockpick"
FurtoVeh.AttrezzoPerHackerare = "hack"

FurtoVeh.CountDown = 120000

FurtoVeh.TempoBlipCryptati = 120000

FurtoVeh.MenuAlign = 'top-right'

FurtoVeh.PosizioneBlipVendita = vector3(1051.2613, -2460.871, 27.862623)
FurtoVeh.BlipVendita = 500
FurtoVeh.ColoreBlipVendita = 3

FurtoVeh.BlipAutoDaRubare = 227
FurtoVeh.ColoreBlipAutoDaRubare = 3

FurtoVeh.BlipMacchinaRubataPerLSPD = 161
FurtoVeh.ColoreBlipMacchinaRubataPerLSPD = 3

FurtoVeh.BlipCryptatoMacchinaRubataPerLSPD = 161
FurtoVeh.ColoreBlipCryptatoMacchinaRubataPerLSPD = 3

FurtoVeh.GridVendita = {
    {
        coordinatevendita = vector3(1051.2613, -2460.871, 27.862623),
        marker = 36,
        rgb = { r = 255, b = 0, g = 0 },
        size = vector3(2.1,2.1,2.1),
        scale = vector3(1.5, 1.5, 1.5),
        texture = ''
    }
}

FurtoVeh.Furtoveicolo = {
    {
        hashnpcfurto = 'cs_lestercrest',
        coordinatemenu = vector3(1275.8204345703,-1710.4871826172,53.771492004395),
        headingnpcfurto = 110.0,
    }
}

FurtoVeh.DizionarioAnimazioni = {
    'oddjobs@assassinate@vice@hooker', --[le animazioni non sono settabili, questo FurtoVeh serve solo per loddare il dizionario]--
    'misscarsteal4@actor',
    'anim@amb@clubhouse@tutorial@bkr_tut_ig3@'
}

FurtoVeh.CoordinateCryptate = {
    vector3(-1408.7514648438,5028.9252929688,81.783645629883),
    vector3(2396.0432128906,2980.9267578125,47.590759277344),
    vector3(-161.51315307617,1164.7602539063,286.19808959961),
    vector3(-2504.6772460938,753.53149414063,301.96984863281),
    vector3(1487.4760742188,368.31219482422,186.89805603027)
}

FurtoVeh.Prezzi = {
    FasciaBassa = {
        Minimo = 40000, 
        Massimo = 70000,
    },
    FasciaMedia = {
        Minimo = 40000,
        Massimo = 70000,
    },
    FasciaAlta = {
        Minimo = 40000,
        Massimo = 70000,
    }
}

FurtoVeh.Macchine = {
    ['FasciaBassa'] = {
        'blista',
        'brioso',
        'prairie'
    },
    ['FasciaMedia'] = {
        'nero',
        'massacro',
        'vacca'
    },
    ['FasciaAlta'] = {
        'feltzer2',
        'rapidgt',
        'sheava'
    }
}

NKZ_Traduzioni = {
    -- CLIENT SIDE
    ["premi-per-dialogare"] = "Premi ~INPUT_CONTEXT~ per dialogare con CARLOS",
    ["premi_per_vendere"] = "Premi ~INPUT_CONTEXT~ per vendere il veicolo",
    ["rischio_basso"] = "Rischio basso",
    ["rischio_medio"] = "Rischio medio",
    ["rischio_alto"] = "Rischio alto",
    ["annulla_furto"] = "Annulla furto veicolo",
    ["title_furto"] = "FURTO VEICOLO",
    ["nome_blip"] = "Macchina rubata",
    ["vendita_blip"] = "Vendita veicolo",
    ["auto_da_rubare"] = "Macchina da rubare",
    ["soffiando_auto"] = "Qualcuno ti sta soffiando l\'auto, corri",
    ["parla_lester_1"] = "Hei amico, ci sarebbe un lavoro per te",
    ["parla_lester_2"] = "Saresti disposto a correre dei rischi? la paga è assicurata!",
    ["no_auto_lester_1"] = "Hei amico! non ci sono può auto da rubare!",
    ["no_auto_lester_2"] = "Se torni più tardi magari ne trovo qualcuna da assegnarti!",
    ["dialogo_inizio_furto_lester_1"] = "Ho trovato un lavoretto per te, attendi che rintraccio il veicolo...",
    ["dialogo_inizio_furto_lester_2"] = "Perfetto! Ho rintracciato il veicolo",
    ["appena_rintracciato_veicolo"] = "Ti è stato mandato un segnale gps nella posizione in cui si trova il veicolo da rubare!",
    ["attendi_rintraccia_veicolo"] = "Attendi che il veicolo venga rintracciato da CARLOS",
    ["facendo_furto"] = "Stai già facendo un furto",
    ["veicolo_sbloccato"] = "Veicolo sbloccato",
    ["grimaldello_rotto"] = "Ti si è rotto il grimaldello!",
    ["altro_furto"] = "Qualcun'altro sta già facendo un furto..!",
    ["scassinamento_fallito"] = "Hai fallito, Riprova..!", 
    ["tempo_scassinamento"] = "Troppo tempo per scassinare, fai in fretta!!!",
    ["no_azione_ora"] = "Non puoi eseguire quest'azione in questo momento!",
    ["già_scassinando"] = "Stai già scassinando!",
    ["no_macchine"] = "Hei bro non accetto macchine ora..!",
    ["no_veicoli_vicini"] = "Nessun veicolo nelle vicinanze", 
    ["tempo_scaduto"] = "Tempo scaduto!",
    ["sistema_hack"] = "Oh oh, la macchina aveva un sistema di sicurezza, per fortuna grazie all\' hack che hai fatto il segnale sarà cryptato",
    ["interno_veicolo"] = "Non sei all'interno del veicolo",
    -- SERVER SIDE
    ["furto_in_corso"] = "Furto veicolo in corso, la macchina ha il gps attaccato, guardare la mappa",
    ["no_furto_polizia"] = "Non puoi farlo da poliziotto",
    ["abbastanza_polizia_basso"] = "Non ci sono abbastanza poliziotti, ne servono: "..FurtoVeh.LSPDRischioBasso,
    ["abbastanza_polizia_medio"] = "Non ci sono abbastanza poliziotti, ne servono: "..FurtoVeh.LSPDRischioMedio,
    ["abbastanza_polizia_alto"] = "Non ci sono abbastanza poliziotti, ne servono: "..FurtoVeh.LSPDRischioAlto,
}