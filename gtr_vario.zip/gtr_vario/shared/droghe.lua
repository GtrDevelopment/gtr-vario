
Droghe = {}

Droghe.BlipRaccolta = {
    ['cannabis'] = {
        Item = 'cannabis',
        reqJob = nil,
        Pos = vec3(-1164.3489, -2023.2079, 13.1605),
        RandomBetween = { 4, 8 },
        minPol = 0
    },
    ['cannabis2'] = {
        Item = 'cannabis',
        reqJob = nil,
        Pos = vec3(2226.4551, 5576.7612, 53.8614),
        RandomBetween = { 4, 8 },
        minPol = 0
    },
    ['fogliadicoca'] = {
        Item = 'fogliadicoca',
        reqJob = nil,
        Pos = vec3(2576.7327, 4648.0615, 34.0337),
        RandomBetween = { 3, 8 },
        minPol = 0
    },
    ['fogliaeroina'] = {
        Item = 'fogliaeroina',
        reqJob = nil,
        Pos = vector3(1899.5015, 4925.0693, 48.8259),
        RandomBetween = { 3, 8 },
        minPol = 0
    },
    ['fogliadihashish'] = {
        Item = 'fogliadihashish',
        reqJob = nil,
        Pos = vector3(2408.2085, 3031.6958, 48.1454),
        RandomBetween = { 3, 8 },
        minPol = 0
    },
    ['mdma'] = {
        Item = 'mdma',
        reqJob = nil,
        Pos = vector3(436.0211, 6456.2271, 28.7437),
        RandomBetween = { 3, 8 },
        minPol = 0
    },
}

Droghe.BlipProcesso = {
    ['cannabis'] = {
        reqItems = {
            ['cannabis'] = 5
        },
        raciveItems = {
            ['marijuana'] = 3
        },
        reqJob = nil,
        Pos = vec3(-120.7718, 1904.1106, 197.3335),
        minPol = 0
    },
    ['fogliadicoca'] = {
        reqItems = {
            ['fogliadicoca'] = 5
        },
        raciveItems = {
            ['cocaina'] = 3
        },
        reqJob = nil,
        Pos = vec3(-1148.2573, 4938.9805, 222.2693),
        minPol = 0
    },
    ['fogliaeroina'] = {
        reqItems = {
            ['fogliaeroina'] = 5
        },
        raciveItems = {
            ['eroina'] = 3
        },
        reqJob = nil,
        Pos = vec3(-98.5402, -2232.3149, 7.8117),
        minPol = 0
    },
    ['fogliadihashish'] = {
        reqItems = {
            ['fogliadihashish'] = 5
        },
        raciveItems = {
            ['hashish'] = 3
        },
        reqJob = nil,
        Pos = vec3(2405.0640, 3027.8770, 48.1526),
        minPol = 0
    },
    ['mdma'] = {
        reqItems = {
            ['mdma'] = 5
        },
        raciveItems = {
            ['mdmapacchetto'] = 3
        },
        reqJob = nil,
        Pos = vec3(2812.9983, 5986.1304, 350.2155),
        minPol = 0
    },

    ['bottigliadivetro'] = {
        reqItems = {
            ['bottigliadivetro'] = 5
        },
        raciveItems = {
            ['whiskyb'] = 5
        },
        reqJob = nil,
        Pos = vec3(707.0154, -965.6814, 30.4128),
        minPol = 0
    },

    ['speedball'] = {
        reqItems = {
            ['cocaina'] = 5,
            ['eroina'] = 5
        },
        raciveItems = {
            ['speedball'] = 5
        },
        reqJob = nil,
        Pos = vec3(30.09231, 3668.519, 40.43445),
        minPol = 0
    },

    ['whiskyb'] = {
        reqItems = 'whiskyb',
        raciveItems = 'whiskymacchiato',
        reqJob = { name = 'peakyblinders', grade = 2 },
        Immediato = true,
        Pos = vec3(-442.5758, -1667.552, 19.01831),
        time = 2000,
        minPol = 0
    },
}
