GTR = {}

GTR.TimerBeforeNewRob    = 60 
GTR.MaxDistance    = 200   



GTR.Stores = {


	["paleto_twentyfourseven"] = {
		position = { x = 1736.32, y = 6419.47, z = 35.03 },
		reward = 40000,
		nameOfStore = "24/7.",
		secondsRemaining = 300, 
		poliziotti = 2,
		lastRobbed = 3500
	},
	["sandyshores_twentyfoursever"] = {
		position = { x = 1961.24, y = 3749.46, z = 32.34 },
		reward = 40000,
		nameOfStore = "24/7. ",
		secondsRemaining = 300, 
		poliziotti = 2,
		lastRobbed = 3500
	},
	["littleseoul_twentyfourseven"] = {
		position = { x = -709.17, y = -904.21, z = 19.21 },
		reward = 40000,
		nameOfStore = "24/7. ",
		secondsRemaining = 300, 
		poliziotti = 2,
		lastRobbed = 3500
	},
	["ocean_liquor"] = {
		position = { x = -2959.33, y = 388.21, z = 14.00 },
		reward = 40000,
		nameOfStore = "Robs Liquor. ",
		poliziotti = 2,
		secondsRemaining = 300, 
		lastRobbed = 3500
	},
	["rancho_liquor"] = {
		position = { x = 1133.538, y = -984.0923, z = 46.39929 },
		reward = 40000,
		nameOfStore = "Robs Liquor.",
		poliziotti = 2,
		secondsRemaining = 300, 
		lastRobbed = 3500
	},
	["sanandreas_liquor"] = {
		position = { x = -1219.85, y = -916.27, z = 11.32 },
		reward = 40000,
		nameOfStore = "Robs Liquor. ",
		secondsRemaining = 300, 
		poliziotti = 2,
		lastRobbed = 3500
	},
	["grove_ltd"] = {
		position = { x = -43.40, y = -1749.20, z = 29.42 },
		reward = 40000,
		nameOfStore = "LTD Gasoline.",
		poliziotti = 2,
		secondsRemaining = 300, 
		lastRobbed = 3500
	},
	["negozietto_125"] = {
		position = { x = 29.85495, y = -1339.978, z = 29.48206 },
		reward = 40000,
		nameOfStore = "247 Negozio.",
		poliziotti = 0,
		secondsRemaining = 10, 
		lastRobbed = 3500
	},
	["mirror_ltd"] = {
		position = { x = 1160.67, y = -314.40, z = 69.20 },
		reward = 40000,
		nameOfStore = "LTD Gasoline.",
		poliziotti = 2,
		secondsRemaining = 300, 
		lastRobbed = 3500
	},
	["pacific"] = {
		position = { x = 253.4769, y = 225.6659, z = 101.8689 },
		reward = 750000,
		nameOfStore = "Pacific Bank.",
		poliziotti = 8,
		secondsRemaining = 500, 
		lastRobbed = 3500
	},
	["blaine_county"] = {
		position = { x = -103.9536, y = 6478.2275, z = 31.6267 },
		reward = 1200000,
		nameOfStore = "Blaine County Bank.",
		poliziotti = 8,
		secondsRemaining = 500, 
		lastRobbed = 3500
	},
	
}