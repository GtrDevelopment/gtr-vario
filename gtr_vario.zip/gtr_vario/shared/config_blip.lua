KrsKaros93 = {}


KrsKaros93.blipPos = {
    {
        pos = vector3(-457.9535, 6018.9272, 37.7951),
        blip = {
            active = true,
            sprite = 58,
            color = 56,
            size = 0.7,
            name = "Sceriffato"
        }
    },
    {
        pos = vector3(-1860.1724, -349.6326, 49.3876),
        blip = {
            active = true,
            sprite = 61,
            color = 35,
            size = 0.7,
            name = "Ospedale"
        }
    },
    {
        pos = vector3(-365.2747, -130.9234, 38.6942),
        blip = {
            active = true,
            sprite = 643,
            color = 30,
            size = 0.7,
            name = "LS Custom"
        }
    },
    {
        pos = vector3(15.2778, -1120.9185, 28.8095),
        blip = {
            active = true,
            sprite = 110,
            color = 15,
            size = 0.7,
            name = "Armeria"
        }
    },
    {
        pos = vector3(-1338.285, -941.8938, 12.353787),
        blip = {
            active = true,
            sprite = 40,
            color = 43,
            size = 0.5,
            name = "Case Popolari"
        }
    },
    {
        pos = vector3(46.9671, -997.5339, 29.3470),
        blip = {
            active = true,
            sprite = 605,
            color = 43,
            size = 0.5,
            name = "Cotto & Mangiato"
        }
    },
    {
        pos = vector3(1217.4999, -1267.2311, 36.4223),
        blip = {
            active = true,
            sprite = 525,
            color = 35,
            size = 0.5,
            name = "Centro impieghi"
        }
    },
    {
        pos = vector3(-794.1127, -1493.1732, 1.5952),
        blip = {
            active = true,
            sprite = 455,
            color = 38,
            size = 0.5,
            name = "Noleggio Barche"
        }
    },
    {
        pos = vector3(151.8551, -226.8742, 59.6698),
        blip = {
            active = true,
            sprite = 606,
            color = 0,
            size = 0.5,
            name = "Negozio Telefono"
        }
    },
    {
        pos = vector3(-3018.2510, 68.4057, 21.6964),
        blip = {
            active = true,
            sprite = 606,
            color = 0,
            size = 0.5,
            name = "Belleviue"
        }
    },
---------------------------------------
    {
        pos = vector3(2202.1528, 5571.6670, 53.7206),
        blip = {
            active = true,
            sprite = 140,
            color = 11,
            size = 0.5,
            name = "Raccolta Cannabis"
        }
    },
    {
        pos = vector3(15.7674, 3687.7498, 38.5723),
        blip = {
            active = true,
            sprite = 140,
            color = 11,
            size = 0.5,
            name = "Processo Cannabis"
        }
    },
    -- Blip Locali
    {
        pos = vector3(-1730.4956, -805.2344, 10.2444),
        blip = {
            active = true,
            sprite = 93,
            color = 38,
            size = 0.7,
            name = "Asgard"
        }
    },
    {
        pos = vector3(-1136.8613, -1712.7656, 5.0791),
        blip = {
            active = true,
            sprite = 93,
            color = 7,
            size = 0.8,
            name = "Tiki Bar"
        }
    },
    {
        pos = vector3(137.4825, -3069.6538, 18.8279),
        blip = {
            active = true,
            sprite = 566,
            color = 64,
            size = 0.8,
            name = "Benny's"
        }
    },
    {
        pos = vector3(337.7465, -915.5754, 30.2994),
        blip = {
            active = true,
            sprite = 93,
            color = 7,
            size = 0.8,
            name = "Tiki Bar"
        }
    },
    {
        pos = vector3(-1388.2920, -587.1343, 30.2184),
        blip = {
            active = true,
            sprite = 93,
            color = 34,
            size = 0.8,
            name = "Bahamas"
        }
    },
    {
        pos = vector3(2500.6643, -385.4167, 96.9231),
        blip = {
            active = true,
            sprite = 60,
            color = 39,
            size = 0.8,
            name = "F.B.I"
        }
    },

    {
        pos = vector3(120.2548, -1286.5070, 28.2602),
        blip = {
            active = true,
            sprite = 121,
            color = 24,
            size = 0.8,
            name = "Vanilla"
        }
    },

    {
        pos = vector3(-1036.0967, -1375.2422, 5.6933),
        blip = {
            active = true,
            sprite = 93,
            color = 1,
            size = 0.8,
            name = "KFC"
        }
    },

    {
        pos = vector3(-211.4845, -1325.1746, 30.8906),
        blip = {
            active = true,
            sprite = 446,
            color = 64,
            size = 0.8,
            name = "Benny's"
        }
    },

    {
        pos = vector3(310.8263, -906.8687, 29.2514),
        blip = {
            active = true,
            sprite = 93,
            color = 8,
            size = 0.8,
            name = "Cyber Bar"
        }
    },

    {
        pos = vector3(269.8377, -826.0065, 29.4603),
        blip = {
            active = true,
            sprite = 93,
            color = 2,
            size = 0.8,
            name = "Starbucks"
        }
    },

    {
        pos = vector3(-1305.3434, -393.9503, 36.6958),
        blip = {
            active = true,
            sprite = 556,
            color = 39,
            size = 0.8,
            name = "Armeria 646"
        }
    },
    {
        pos = vector3(1692.8348, 3759.0784, 34.7053),
        blip = {
            active = true,
            sprite = 556,
            color = 39,
            size = 0.8,
            name = "Armeria 1022"
        }
    },
    {
        pos = vector3(-331.7357, 6083.7441, 37.6751),
        blip = {
            active = true,
            sprite = 556,
            color = 39,
            size = 0.8,
            name = "Armeria Paleto"
        }
    },
    {
        pos = vector3(812.1782, -2156.2129, 29.6119),
        blip = {
            active = true,
            sprite = 556,
            color = 39,
            size = 0.8,
            name = "Armeria 60"
        }
    },

-- BLIP OSPEDALE

{
    pos = vector3(-1860.1724, -349.6326, 49.3876),
    blip = {
        active = true,
        sprite = 403,
        color = 11,
        size = 0.8,
        name = "Farmacia"
    }
},

    --BLIP BANCHE

    {
        pos = vector3(-629.3727, -236.0336, 38.0571),
        blip = {
            active = true,
            sprite = 617,
            color = 18,
            size = 0.8,
            name = "Gioielleria"
        }
    },

    {
        pos = vector3(247.6852, -51.3022, 69.9411),
        blip = {
            active = true,
            sprite = 110,
            color = 15,
            size = 0.7,
            name = "armeria 578"
        }
    }, 
    {
        pos = vector3(-1096.7078, -850.1664, 13.6874),
        blip = {
            active = true,
            sprite = 60,
            color = 3,
            size = 0.8,
            name = "Centrale Di Polizia"
        }
    },
}
