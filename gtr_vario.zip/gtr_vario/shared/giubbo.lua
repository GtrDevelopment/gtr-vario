GTR = {}

GTR.Config = {
    {x = 143.6413, y = -641.4795, z = 269.3415, heading = 345.1664 },
}