local ConnectedCops = 0

function do_tables_match( a, b )
    for k, v in pairs(b) do
        if type(v) == 'table' then
            for kk, vv in pairs(v) do
                if vv ~= a[k][kk] then
                    return false
                end
            end
        else
            if a[k] ~= v then
                return false
            end
        end
    end

    return true
end

local LastUsage = {}

RegisterServerEvent('el_smallresources:DaiDroga', function(data, index)
    local src = source
    if do_tables_match(data, Droghe.BlipRaccolta[index]) then
        print("Passato")
        if ConnectedCops >= data.minPol then
            local pCoords = GetEntityCoords(GetPlayerPed(src))
            local xPlayer = ESX.GetPlayerFromId(src)
            if #(pCoords - data.Pos) <= 3 then
                if not data.reqJob or (data.reqJob and (data.reqJob == xPlayer.job.name)) then
                    local qty = math.random(data.RandomBetween[1], data.RandomBetween[2])
                    if xPlayer.canCarryItem(data.Item, qty) then
                        if LastUsage[src] then
                            if os.time() - LastUsage[src] < 8 then
                                return
                            end
                        else
                            LastUsage[src] = os.time()
                        end

                        ESX.Log('https://discord.com/api/webhooks/1186299232131489852/JfSGl8fT_BNgMb8YU6pdaTdhyp8DTAMsLLE1i1mu9pyikDG0PvJuEFiXGDTzvgX0tyA9', 'Il player **'.. GetPlayerName(src) ..'** ha raccolto x**'.. qty .. ' di '.. data.Item ..'**')
                        xPlayer.addInventoryItem(data.Item, qty)
                    else
                        TriggerClientEvent('esx:showNotification', src, 'Non hai abbastanza spazio!')
                    end
                end
            end
        else
            TriggerClientEvent('esx:showNotification', src, 'Non ci sono abbastanza poliziotti!')
        end
    end
end)

RegisterServerEvent('el_smallresources:ProcessoDroga', function(data, index)
    local src = source
    if do_tables_match(data, Droghe.BlipProcesso[index]) then
        if ConnectedCops >= data.minPol then
            local pCoords = GetEntityCoords(GetPlayerPed(src))
            local xPlayer = ESX.GetPlayerFromId(src)
            if #(pCoords - data.Pos) <= 3 then
                if not data.reqJob or (data.reqJob and ((data.reqJob.name == xPlayer.job.name and data.reqJob.grade <= xPlayer.job.grade))) then
                    if not data.Immediato then
                        for k, v in pairs(data.reqItems) do
                            local invItem = xPlayer.getInventoryItem(k)
                            if invItem.count < v then
                                xPlayer.showNotification('Non hai abbastanza '.. invItem.label)
                                return
                            end
                        end
                    end

                    if LastUsage[src] then
                        if os.time() - LastUsage[src] < 6 then
                            return
                        end
                    else
                        LastUsage[src] = os.time()
                    end
        
                    if not data.Immediato then
                        local FormattedTextR = ''
                        for k, v in pairs(data.reqItems) do
                            xPlayer.removeInventoryItem(k, v)
                            FormattedTextR = FormattedTextR .. ' x'.. v ..' di '.. k
                        end
            
                        local FormattedTextD = ''
                        for k, v in pairs(data.raciveItems) do
                            xPlayer.addInventoryItem(k, v)
                            FormattedTextD = FormattedTextD .. ' x'.. v ..' di '.. k
                        end
        
                        ESX.Log('https://discord.com/api/webhooks/1186299362712748192/xsaeFtWMy-gLU3OoiO84vOZOJg3X7OZwYJmgt0bR96Z_W-cqUzffzkG0vGiOLdiLO8dT', 'Il player **'.. GetPlayerName(src) ..'** ha processato **'.. FormattedTextR ..'** in **'.. FormattedTextD ..'**')
                    else
                        local itemCount = xPlayer.getInventoryItem(data.reqItems).count
                        if itemCount > 0 then
                            xPlayer.removeInventoryItem(data.reqItems, itemCount)
                            xPlayer.addInventoryItem(data.raciveItems, itemCount)
                        end
                    end
                end
            end
        else
            TriggerClientEvent('esx:showNotification', src, 'Non ci sono abbastanza poliziotti!')
        end
    end
end)