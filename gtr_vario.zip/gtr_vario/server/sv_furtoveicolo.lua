ESX = exports["es_extended"]:getSharedObject()
local attendialtrofurto = true
local persona
local furtoinprogress = {}

RegisterServerEvent('nkz_vendita')
AddEventHandler('nkz_vendita', function(tipoauto)
    local xPlayer = ESX.GetPlayerFromId(source)
    if tipoauto == 'FasciaBassa' then
        local prezzo = math.random(FurtoVeh.Prezzi.FasciaBassa.Minimo, FurtoVeh.Prezzi.FasciaBassa.Massimo)
        if FurtoVeh.SoldiSporchi then
            xPlayer.addAccountMoney('black_money', prezzo)
            for k in pairs(furtoinprogress) do
                furtoinprogress[k] = nil
            end
            CountDown()
        else
            xPlayer.addMoney(prezzo)
            for k in pairs(furtoinprogress) do
                furtoinprogress[k] = nil
            end
            CountDown()
        end
    elseif tipoauto == 'FasciaMedia' then
        local prezzo = math.random(FurtoVeh.Prezzi.FasciaMedia.Minimo, FurtoVeh.Prezzi.FasciaMedia.Massimo)
        if FurtoVeh.SoldiSporchi then
            xPlayer.addAccountMoney('black_money', prezzo)
            for k in pairs(furtoinprogress) do
                furtoinprogress[k] = nil
            end
            CountDown()
        else
            xPlayer.addMoney(prezzo)
            for k in pairs(furtoinprogress) do
                furtoinprogress[k] = nil
            end
            CountDown()
        end
    elseif tipoauto == 'FasciaAlta' then
        local prezzo = math.random(FurtoVeh.Prezzi.FasciaAlta.Minimo, FurtoVeh.Prezzi.FasciaAlta.Massimo)
        if FurtoVeh.SoldiSporchi then
            xPlayer.addAccountMoney('black_money', prezzo)
            for k in pairs(furtoinprogress) do
                furtoinprogress[k] = nil
            end
            CountDown()
        else
            xPlayer.addMoney(prezzo)
            for k in pairs(furtoinprogress) do
                furtoinprogress[k] = nil
            end
            CountDown()
        end
    end
end)

function CountDown()
    attendialtrofurto = false
    Citizen.Wait(FurtoVeh.CountDown)
    attendialtrofurto = true
end

ESX.RegisterServerCallback("Coordinate", function(source, cb)
    local player = persona
    local ped = GetPlayerPed(player)
    local coordinate = GetEntityCoords(ped)
    cb(coordinate)
end)

ESX.RegisterServerCallback("GiangiTempoRimanente", function(source, cb)
    cb(attendialtrofurto)
end)

ESX.RegisterServerCallback("Giangi_ControlloDelJob", function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local lavoro = xPlayer.job.name
    if json.encode(furtoinprogress) == "[]" then
        table.insert(furtoinprogress, source)
    end
    cb(lavoro, furtoinprogress, source)
end)

AddEventHandler('playerDropped', function (reason)
    for k,v in pairs(furtoinprogress) do   
        if v == source then
            table.remove(furtoinprogress, v)
        end
    end
end)
  

RegisterServerEvent('nkz_bliperpolizia')
AddEventHandler('nkz_bliperpolizia', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    persona = source
    local xPlayers = ESX.GetExtendedPlayers('job', FurtoVeh.LSPD)
    for nkz, Nikquz in pairs(xPlayers) do
        TriggerClientEvent('nkz_blipfurto', Nikquz.source)
        Nikquz.showNotification(NKZ_Traduzioni["furto_in_corso"])
        Citizen.Wait(45000)
        TriggerClientEvent('nkz_blipcryptati', Nikquz.source)
    end
end)

RegisterServerEvent('nkz_furtolivellobasso')
AddEventHandler('nkz_furtolivellobasso', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local xPlayers = ESX.GetExtendedPlayers('job', FurtoVeh.LSPD)
    if xPlayer.job.name == FurtoVeh.LSPD then
        xPlayer.showNotification(NKZ_Traduzioni["no_furto_polizia"])
    elseif #xPlayers >= FurtoVeh.LSPDRischioBasso then
        TriggerClientEvent('nkz_rischiobasso', source)
    else
        xPlayer.showNotification(NKZ_Traduzioni["abbastanza_polizia_basso"])
    end
end)

RegisterServerEvent('nkz_furtolivellomedio')
AddEventHandler('nkz_furtolivellomedio', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    local xPlayers = ESX.GetExtendedPlayers('job', FurtoVeh.LSPD)
    if xPlayer.job.name == FurtoVeh.LSPD then
        xPlayer.showNotification(NKZ_Traduzioni["no_furto_polizia"])
    elseif #xPlayers >= FurtoVeh.LSPDRischioMedio then
        TriggerClientEvent('nkz_rischiomedio', source)
    else
        xPlayer.showNotification(NKZ_Traduzioni["abbastanza_polizia_medio"])
    end
end)

RegisterServerEvent('nkz_furtolivelloalto')
AddEventHandler('nkz_furtolivelloalto', function()
    local source = source
    local xPlayer = ESX.GetPlayerFromId(source)
    local xPlayers = ESX.GetExtendedPlayers('job', FurtoVeh.LSPD)
    if xPlayer.job.name == FurtoVeh.LSPD then
        xPlayer.showNotification(NKZ_Traduzioni["no_furto_polizia"])
    elseif #xPlayers >= FurtoVeh.LSPDRischioAlto then
        TriggerClientEvent('nkz_rischioalto', source)
    else
        xPlayer.showNotification(NKZ_Traduzioni["abbastanza_polizia_alto"])
    end
end)

RegisterServerEvent('nkz_togligrimaldello')
AddEventHandler('nkz_togligrimaldello', function()
    local xPlayer = ESX.GetPlayerFromId(source)
    xPlayer.removeInventoryItem(FurtoVeh.AttrezzoPerScassinare, 1)
end)

ESX.RegisterUsableItem(FurtoVeh.AttrezzoPerScassinare, function(source)
	TriggerClientEvent("nkz_scassina", source)
end)

ESX.RegisterUsableItem(FurtoVeh.AttrezzoPerHackerare, function(source)
    TriggerClientEvent("nkz_voltlab", source)
end)