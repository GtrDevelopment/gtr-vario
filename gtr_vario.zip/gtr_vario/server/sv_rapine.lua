local rob = false
local robbers = {}


ESX = exports.es_extended:getSharedObject()


RegisterServerEvent('gtr_rapine:tooFar')
AddEventHandler('gtr_rapine:tooFar', function(currentStore)
	local _source = source
	local xPlayers = ESX.GetPlayers()
	rob = false

	for i=1, #xPlayers, 1 do
		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		
		if xPlayer.job.name == 'police' then
			TriggerClientEvent('esx:showNotification', xPlayers[i], 'Rapina annullata al: '..GTR.Stores[currentStore].nameOfStore)
			TriggerClientEvent('gtr_rapine:killBlip', xPlayers[i])
		end
	end

	if robbers[_source] then
		TriggerClientEvent('gtr_rapine:tooFar', _source)
		robbers[_source] = nil
		TriggerClientEvent('esx:showNotification', _source, 'Rapina annullata al: '..GTR.Stores[currentStore].nameOfStore)
	end
end)




ESX.RegisterServerCallback('gepoliceplayers', function(source, cb)
	local cops = 0
	local xPlayers = ESX.GetPlayers()
	for i=1, #xPlayers, 1 do
		local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
		if xPlayer.job.name == 'police' then
			cops = cops + 1
		end
	end
	cb(cops)
end)




RegisterServerEvent('gtr_rapine:robberyStarted')
AddEventHandler('gtr_rapine:robberyStarted', function(currentStore, poliziottirichiesti, job)
	local _source  = source
	local xPlayer  = ESX.GetPlayerFromId(_source)
	local xPlayers = ESX.GetPlayers()

	if GTR.Stores[currentStore] then
		local store = GTR.Stores[currentStore]

		if (os.time() - store.lastRobbed) < GTR.TimerBeforeNewRob and store.lastRobbed ~= 0 then
			TriggerClientEvent('esx:showNotification', _source, 'Questo negozio è gia stato rapinato, aspetta: '..GTR.TimerBeforeNewRob - (os.time() - store.lastRobbed))
			return
		end

		if not rob then
			rob = true

			for i=1, #xPlayers, 1 do
				local xPlayer = ESX.GetPlayerFromId(xPlayers[i])
				if xPlayer.job.name == 'police' then
					TriggerClientEvent('esx:showNotification', xPlayers[i], 'la rapina è incorso: ' ..store.nameOfStore)
					TriggerClientEvent('gtr_rapine:setBlip', xPlayers[i], GTR.Stores[currentStore].position)
				end
			end

			TriggerClientEvent('esx:showNotification', _source, 'Hai iniziato una rapine: ' ..store.nameOfStore)
			TriggerClientEvent('esx:showNotification', _source, 'L\'allarme ha avisato la polizia')
			
			TriggerClientEvent('gtr_rapine:currentlyRobbing', _source, currentStore)
			TriggerClientEvent('gtr_rapine:startTimer', _source)
			
			GTR.Stores[currentStore].lastRobbed = os.time()
			robbers[_source] = currentStore

			SetTimeout(store.secondsRemaining * 1000, function()
				if robbers[_source] then
					rob = false
					if xPlayer then
						TriggerClientEvent('gtr_rapine:robberyComplete', _source, store.reward)
						xPlayer.addAccountMoney('black_money', store.reward)
						local xPlayers, xPlayer = ESX.GetPlayers(), nil
						for i=1, #xPlayers, 1 do
							xPlayer = ESX.GetPlayerFromId(xPlayers[i])

							if xPlayer.job.name == 'police' then
								TriggerClientEvent('esx:showNotification', xPlayers[i], 'Rapina finita: '..store.nameOfStore)
								TriggerClientEvent('gtr_rapine:killBlip', xPlayers[i])
							end
						end
					end
				end
			end)
		
		else
			TriggerClientEvent('esx:showNotification', _source, 'E\' già in corso una rapina')
		end
	else 
		TriggerEvent("Krs:LogDiscord",'**MODDER:** rapina\nnome: '..GetPlayerName(_source)..'\nsteam: '..xPlayer.getIdentifier() , '')
	end
end)