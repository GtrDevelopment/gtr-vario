ESX.RegisterUsableItem('armour', function(source)
    TriggerClientEvent('steffone:armour:metti', source)
end)

ESX.RegisterServerCallback('steffone:armour:check', function(source, cb)
    local xPlayer = ESX.GetPlayerFromId(source)
    local hasArmour = xPlayer.getInventoryItem('armour').count
    if hasArmour > 0 then
        xPlayer.removeInventoryItem('armour', 1)
        ESX.Log('https://discord.com/api/webhooks/1185244607592796180/rvATJo5yaN3mW48hE-vBkWK0PY3sEkNQ7lbJVWkl7Jb_mctDaiCgrVMIpk86TIX70GIw', 'Il player **'..GetPlayerName(source)..'** ha usato un giubbotto')
        cb(true)
    else
        cb(false)
    end
end)