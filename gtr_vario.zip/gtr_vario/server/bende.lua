ESX.RegisterUsableItem('bandage', function(src, args)
    TriggerClientEvent('vario:UsaBenda', src)
end)

ESX.RegisterUsableItem('medikit', function(src, args)
    TriggerClientEvent('vario:UsaMedikit', src)
end)

ESX.RegisterServerCallback('vario:TogliBenda', function(src, cb)
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer.getInventoryItem('bandage').count >= 1 then
        xPlayer.removeInventoryItem('bandage', 1)
        cb(true)
    else
        cb(false)
    end
end)

ESX.RegisterServerCallback('vario:TogliMedikit', function(src, cb)
    local xPlayer = ESX.GetPlayerFromId(src)
    if xPlayer.getInventoryItem('medikit').count >= 1 then
        xPlayer.removeInventoryItem('medikit', 1)
        cb(true)
    else
        cb(false)
    end
end)