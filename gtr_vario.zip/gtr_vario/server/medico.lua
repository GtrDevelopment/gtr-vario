-- ESX.RegisterServerCallback('vario:ControllaAmbulanza', function(src, cb)
--   cb(#GetCount('ambulance'))
-- end)


RegisterServerEvent('steffone:medico:Comando', function()
  local src = source
  function sendToDiscord(webhook, messaggio)
    local contenuto = {{
      author = {
        name = "BOMBARP",
        icon_url = "https://cdn.discordapp.com/attachments/1179786764488028170/1180848211343188089/Natalizio.gif?ex=657ee998&is=656c7498&hm=d7a879812347ba2328e8abb0821f515ea54d6faef9a435473a490cf494e0104f&"
      },
      description = messaggio,
      color = 32768,
      footer = {
        text = "BOMBARP LOG | "..os.date("%x | %X %p"),
      }
    }}
    PerformHttpRequest(webhook , function(err, text, headers) end, 'POST', json.encode({username = name, embeds = contenuto}), { ['Content-Type'] = 'application/json' })
  end
  
  ESX.Log = function(webhook, messaggio)
      sendToDiscord(webhook, messaggio)
  end

  
  ESX.Log('https://discord.com/api/webhooks/1181701426615959612/uV9w1GJ-7eEhxb1Qr5rwHsW1h3l1LKO-lhwIEkCIusDenKe22X4wh-9yDf34ozJ6Lt9E',"Il player **".. GetPlayerName(src) .."** ha fatto /medico")
end)