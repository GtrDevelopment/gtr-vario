fx_version 'cerulean'
game 'gta5'
lua54 'yes'

name 'gtr'

author 'VARIO BY GTR'

shared_script "@es_extended/imports.lua"
shared_script '@ox_lib/init.lua'
shared_script 'shared/droghe.lua'

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'shared/**.lua',
    'server/**.lua',
}

client_scripts {
    'shared/**.lua',
    'client/**.lua',
}

-- data_file "PED_METADATA_FILE" "kids.xml"

-- data_file 'PED_METADATA_FILE' 'peds.meta'

