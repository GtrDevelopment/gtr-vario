local appid = '' 
local asset = ''

function SetRP()
    local name = GetPlayerName(PlayerId())
    local id = GetPlayerServerId(PlayerId())
    SetRichPresence('[' .. id .. '] ' .. name .. ' | ɢɪᴏᴄᴀɴᴅᴏ ꜱᴜ ')
    SetDiscordAppId(appid)
    SetDiscordRichPresenceAsset(asset)
    SetDiscordRichPresenceAssetSmallText('https://discord.gg/')
    SetDiscordRichPresenceAction(1, "Entra sul Discord", "https://discord.gg/")
    SetDiscordRichPresenceAction(0, "Gioca su ", "")
end

Citizen.CreateThread(function()
    while true do
        SetRP()
        Wait(60000)
    end
end)