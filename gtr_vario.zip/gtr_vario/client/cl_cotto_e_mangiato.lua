ESX = exports["es_extended"]:getSharedObject()
local isDoing = false


local options = {
    {
        icon = 'fa-solid fa-burger',
        label = 'Mangia/Bevi',
        onSelect = function(data)
            ApriMenuCibo()
        end,
        canInteract = function(entity, distance, coords, name, bone)
            return not IsEntityDead(entity)
        end
    },
}

Citizen.CreateThread(function()
    local model = 'a_m_m_fatlatin_01'
    lib.requestModel(model)

    npc = CreatePed(4, model, 46.9658, -998.1024, 28.3480, 343.0224, false, true)
    FreezeEntityPosition(npc, true)
    SetEntityInvincible(npc, true)
    SetBlockingOfNonTemporaryEvents(npc, true)
    exports.ox_target:addLocalEntity(npc, options)
end)

function ApriMenuCibo()
    local elements = {
        {label = 'Mangia [1000$]', value = 'mangia'},
        {label = 'Bevi [1000$]', value = 'bevi'}
    }
    ESX.UI.Menu.CloseAll()
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'shopcibo_automatico', {
        title = 'Cotto e mangiato',
        align = 'bottom-right',
        elements = elements
    }, function(data, menu)
        if not isDoing then
            if data.current.value == 'mangia' then
                ExecuteCommand('e burger')
                TriggerEvent('esx_status:add', 'hunger', 500000)
                exports.rprogress:Start("Mangiando...", 3000)
                ExecuteCommand('e c')
            elseif data.current.value == 'bevi' then
                ExecuteCommand('e water')
                TriggerEvent('esx_status:add', 'thirst', 500000)
                exports.rprogress:Start("Bevendo...", 3000)
                ExecuteCommand('e c')
            end
            isDoing = true
            ESX.TriggerServerCallback('checkSoldi', function(haSoldi)
                if haSoldi then
                    ESX.ShowNotification('Aquista dai locali per spendere meno')
                end
                isDoing = false
            end, 1000)
        end
    end, function(data, menu)
        menu.close()
    end)
end