RegisterNetEvent('steffone:armour:metti', function()
    exports.rprogress:Custom({
        Async = true,
        canCancel = true,       -- Allow cancelling
        cancelKey = 178,        -- Custom cancel key
        Duration = 2000,
        Label = "Mettendo il giubbotto...",
        DisableControls = {
            Mouse = false,
            Player = false,
            Vehicle = false
        },
        Animation = {
            animationDictionary = "clothingshirt", -- https://alexguirre.github.io/animations-list/
            animationName = "try_shirt_positive_d",
        },
        onComplete = function(cancelled)
            if not cancelled then
                ESX.TriggerServerCallback('steffone:armour:check', function(hasArmour)
                    if hasArmour then
                        SetPedArmour(cache.ped, 100)
                    else
                        ESX.ShowNotification('Non hai armatura')
                    end
                end)
            end
        end
    })
end)