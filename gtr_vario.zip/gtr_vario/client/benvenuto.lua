CreateThread(function()
    for i = 1, 4 do
        ExecuteCommand('me Benvenuto Su ~b~Arrivato Su Gtr')
        Wait(5000)
    end
end)