local Pos = {
    {
        Pos = vec3(596.4257, -8.7829, 106.8749),
        Lavoro = 'police'
    },

    {
        Pos = vector3(2517.2681, -374.5870, 93.1485),
        Lavoro = 'fbi'
    },

    {
        Pos = vector3(-542.2975, -192.0554, 38.2197),
        Lavoro = 'governo'
    },

    {
        Pos = vector3(-438.0262, 6012.6748, 36.9956),
        Lavoro = 'sceriffato'
    },

    {
        Pos = vector3(-464.7378, 6004.3364, 31.4892),
        Lavoro = 'sceriffato'
    },

    {
        Pos = vector3(-1469.3953, -43.9003, 58.6684),
        Lavoro = 'carteljalisco'
    },

    {
        Pos = vector3(2176.0317, 5116.4160, 58.8053),
        Lavoro = 'casadicarta'
    },
}


-- Citizen.CreateThread(function() 
--     Wait(250)
--     for k, v in pairs(Pos) do
--         TriggerEvent('gridsystem:registerMarker', {
--             name = 'Blip_Giubbotto_'..k,
--             pos = v.Pos,
--             scale = vector3(0.7, 0.7, 0.7),
--             size = vector3(2.0, 2.0, 2.0),
--             msg = 'Premi [E] per prendere il giubbotto',
--             control = 'E',
--             type = -1,
--             texture = 'bombarp',
--             shouldBob = false,
--             shouldRotate = true,
--             permission = v.Lavoro,
--             color = { r = 255, g = 255, b = 255 },
--             action = function()
--                 SetPedArmour(cache.ped, 100)
--             end
--         })
--     end
-- end)

local options = {
    {
        icon = 'fa-solid fa-vest',
        label = 'Prendi Giubotto',
        onSelect = function(data)
            ESX.ShowNotification('Hai Messo il giubotto')
            SetPedArmour(cache.ped, 100)
        end,
        canInteract = function(entity, distance, coords, name, bone)
            return not IsEntityDead(entity)
        end
    },
}

Citizen.CreateThread(function()
    local model = 's_m_y_ammucity_01'
    lib.requestModel(model)

    for stf, steffone in pairs(GTR.Config) do
        npc = CreatePed(4, model, steffone.x, steffone.y, steffone.z, steffone.heading, false, true)
        FreezeEntityPosition(npc, true)
        SetEntityInvincible(npc, true)
        SetBlockingOfNonTemporaryEvents(npc, true)
        exports.ox_target:addLocalEntity(npc, options)
    end
end)