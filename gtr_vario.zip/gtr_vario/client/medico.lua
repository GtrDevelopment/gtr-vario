
RegisterNetEvent("chiamamedico")
AddEventHandler("chiamamedico", function()
    
    ESX.TriggerServerCallback('checkJobsON', function(mediciOnline)
	if exports['atx_death']:ThePlayerIsDead(true) then
        if mediciOnline <= 1 then
            TriggerServerEvent('chatazionefix')
            -- ExecuteCommand('me Chiamando ~o~Medico')
            exports.rprogress:Start("Hai chiamato un medico...", 200000)
            TriggerEvent('atx_death:revive')
            TriggerServerEvent("toglisoldi")
            ESX.ShowNotification('Hai pagato $1500', 'success')
        else
            ESX.ShowNotification('Ci sono '..mediciOnline..' medici online', 'error')
         end
    	else
			ESX.ShowNotification('Sei ancora cosciente!')
		end
	end, false)
end)


RegisterCommand('medico', function()
    TriggerEvent('chiamamedico')
end) 





