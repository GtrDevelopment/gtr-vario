
    
    CreateThread(function()
        for i = 1, #KrsKaros93.blipPos, 1 do
            local KrsKaros93 = KrsKaros93.blipPos[i]

            if KrsKaros93.blip.active then 
            local blip = AddBlipForCoord(KrsKaros93.pos.x, KrsKaros93.pos.y, KrsKaros93.pos.z)
            SetBlipSprite (blip, KrsKaros93.blip.sprite)
            SetBlipDisplay(blip, 4)
            SetBlipScale  (blip, KrsKaros93.blip.size)
            SetBlipColour (blip, KrsKaros93.blip.color)
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName("STRING")
            AddTextComponentString(KrsKaros93.blip.name)
            EndTextCommandSetBlipName(blip)
        end
    end
end)