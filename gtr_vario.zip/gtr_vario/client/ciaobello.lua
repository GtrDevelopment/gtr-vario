local crouched = false

local function crouch()

    local playerPed = cache.ped or PlayerPedId()

    if not IsEntityDead(playerPed) and not IsPedInAnyVehicle(playerPed, true) then

        DisableControlAction(0, 36, true)

        CreateThread(function()           
         
            lib.requestAnimSet('move_ped_crouched')

            if crouched then 
                ResetPedMovementClipset(playerPed, 0.30)
                crouched = false 
            else
                SetPedMovementClipset(playerPed, 'move_ped_crouched', 0.30)
                crouched = true
            end 
        end)
    end 
end

RegisterCommand("crouch", crouch)

RegisterKeyMapping("crouch", "Press CTRL to crouch", "keyboard", "LCONTROL")

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local ped = cache.ped
        if IsPedArmed(ped, 6) then
            DisableControlAction(1, 140, true)
            DisableControlAction(1, 141, true)
            DisableControlAction(1, 142, true)
        else
            Wait(1500)
        end
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(0)
        local ped = cache.ped
        if ped ~= nil then
            DisableControlAction(1, 44, true)
        else
            Wait(1500)
        end
    end
end)

CreateThread(function()
    while true do
        sleep = 1500
        local playerPed = PlayerPedId()
        local vehicle = GetVehiclePedIsIn(playerPed, false)
        local isBike = GetVehicleClass(vehicle) == 8

        if not vehicle or not isBike then
            goto skip
        end

        sleep = 0
        DisableControlAction(0, 345, true)
        ::skip::
        Wait(sleep)
    end
end)

Citizen.CreateThread(function()
    while true do
        Citizen.Wait(100)
        local ped = cache.ped
        if IsPedJumping(ped) then
            if IsPedOnFoot(ped) and not IsPedSwimming(ped) and (IsPedRunning(ped) or IsPedSprinting(ped)) and not IsPedClimbing(ped) and not IsPedRagdoll(ped) then
                local chance_result = math.random()
                if chance_result < 0.80 then 
                    Citizen.Wait(600)
                    ShakeGameplayCam('SMALL_EXPLOSION_SHAKE', 0.10) 
                    SetPedToRagdoll(ped, 4000, 1, 2)
                else
                    Citizen.Wait(2000)
                end
            end
        end
    end
end)

RegisterCommand('finger', function()
 
    local ped = PlayerPedId()

    repeat

        RequestAnimDict('anim@mp_point')

        Wait(0)
    until HasAnimDictLoaded('anim@mp_point')
    
    TaskMoveNetworkByName(ped, 'task_mp_pointing', 0.1, 0, 'anim@mp_point', 24)
    RemoveAnimDict('anim@mp_point')
    
    while IsControlPressed(0, 29) do
       
        SetTaskMoveNetworkSignalFloat(ped, 'Pitch', (GetGameplayCamRelativePitch() + 100) / 110)
        
        SetTaskMoveNetworkSignalFloat(ped, 'Heading', (GetGameplayCamRelativeHeading() + 190) / 360 * -1.0 + 1.0)
        
        Wait(16)
    end
    
    RequestTaskMoveNetworkStateTransition(ped, 'Stop')
    
    ClearPedSecondaryTask(ped)
end)

RegisterKeyMapping('finger', 'Puntare il dito', 'tastiera', 'b')

Citizen.CreateThread(function()
    local dict = "missminuteman_1ig_2"
    
    RequestAnimDict(dict)
    while not HasAnimDictLoaded(dict) do
        Citizen.Wait(100)
    end
    local handsup = false
    while true do
        Citizen.Wait(0)
        if IsControlJustPressed(1, 323) then --Start holding X
            if not handsup then
                TaskPlayAnim(GetPlayerPed(-1), dict, "handsup_enter", 8.0, 8.0, -1, 50, 0, false, false, false)
                handsup = true
            else
                handsup = false
                ClearPedTasks(GetPlayerPed(-1))
            end
        end
    end
end)

RegisterKeyMapping("handsUp", "Press X to put hands in the air", "keyboard", "X")