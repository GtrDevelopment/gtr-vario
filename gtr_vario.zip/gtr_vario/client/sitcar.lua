local inSit = false

exports("InSit", function()
    return inSit
end)

RegisterCommand('sitcar', function(src)
    local veh, dist = ESX.Game.GetClosestVehicle()
    if exports['atx_death']:ThePlayerIsDead() then
        return
    end

    -- if exports['vario']:Ammanettato() then
    --     return
    -- end
    
    if veh ~= -1 and dist <= 3.0 then
        local pPed = cache.ped
        if not IsPedInAnyVehicle(pPed) then
            if not inSit then
                ESX.ShowNotification('Ti sei seduto sul veicolo!')
                ExecuteCommand('e sit5')
                --AttachEntityToEntity(cache.ped, veh, GetPedBoneIndex(veh, 28422), 0.0, -1.0, -1.0, 0.0, 0.0, 0.0, 1, 1, 0, 1, 0, 1)
                AttachEntityToEntity(pPed, veh, -1, 0.0, 0.0, 1.0, 0.0, 0.0, 0.0, false, false, false, false, 20, true)
                inSit = true
            else
                ESX.ShowNotification('Ti sei alzato dal veicolo!')
                ClearPedTasks(pPed)
                DetachEntity(pPed)
                inSit = false
            end
        else
            ESX.ShowNotification('Non puoi fare questo comando da dentro un veicolo!')
        end
    else
        ESX.ShowNotification('Nessun veicolo vicino')
    end
end, false)