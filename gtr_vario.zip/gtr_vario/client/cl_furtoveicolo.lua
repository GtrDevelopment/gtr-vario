ESX = exports.es_extended:getSharedObject()

local furto = true
local scassinando = false
local staparlando = false

function NXN(message, durata)
    durata = durata or 3500
    ClearPrints()
    SetTextEntry_2("STRING")
    AddTextComponentString(message)
    DrawSubtitleTimed(durata, 1)
end

Citizen.CreateThread(function()
    for k, v in pairs(FurtoVeh.Furtoveicolo) do
        
        if not HasModelLoaded(v.hashnpcfurto) then
            RequestModel(v.hashnpcfurto)
            while not HasModelLoaded(v.hashnpcfurto) do
                Citizen.Wait(5)
            end
        end
        
        for k, v in pairs(FurtoVeh.DizionarioAnimazioni) do
            if not HasAnimDictLoaded(v) then
                RequestAnimDict(v)
                while not HasAnimDictLoaded(v) do
                    Citizen.Wait(5)
                end
            end
        end

        for k, v in pairs(FurtoVeh.Macchine) do
            for i, j in ipairs(v) do
            
                if not HasModelLoaded(j) then
                    RequestModel(j)
                    while not HasModelLoaded(j) do
                        Citizen.Wait(5)
                    end
                end
            end
        end
        
        Nikquz = CreatePed(4, v.hashnpcfurto, v.coordinatemenu[1], v.coordinatemenu[2], v.coordinatemenu[3], v.headingnpcfurto, false, true)
        FreezeEntityPosition(Nikquz, true)
        SetEntityInvincible(Nikquz, true)
        SetBlockingOfNonTemporaryEvents(Nikquz, true)
    end
end)




local options = {
    {
        icon = 'fa-solid fa-burger',
        label = 'Open',
        onSelect = function(data)
            ESX.TriggerServerCallback("GiangiTempoRimanente", function(attendialtrofurto) 
                ESX.TriggerServerCallback("Giangi_ControlloDelJob", function(lavoro, furtoinprogress, id) 
                    local staparlando = false
                    for k,v in pairs(furtoinprogress) do
                        if v == id then
                            if attendialtrofurto then
                                if not staparlando then
                                    if lavoro ~= FurtoVeh.LSPD then
                                        TriggerEvent('nkz_dialogo')
                                        Citizen.Wait(7000)
                                        staparlando = false
                                        TriggerEvent('dialogo_inizio_furto')
                                        Citizen.Wait(15000)
                                        ESX.ShowNotification(NKZ_Traduzioni["appena_rintracciato_veicolo"])
                                        TriggerServerEvent('nkz_furtolivellomedio')
                                    else 
                                        ESX.ShowNotification(NKZ_Traduzioni["no_furto_polizia"])
                                    end
                                else
                                    ESX.ShowNotification(NKZ_Traduzioni["facendo_furto"])
                                end
                            else
                                TriggerEvent('dialogo2')
                            end
                        else
                            ESX.ShowNotification(NKZ_Traduzioni["altro_furto"])
                        end
                    end
                end)
            end)
        end,
        canInteract = function(entity, distance, coords, name, bone)
            return not IsEntityDead(entity)
        end
    },
}


Citizen.CreateThread(function()
    local model = 's_m_y_prismuscl_01'
    lib.requestModel(model)

    npc = CreatePed(4, model, -2175.592, 4294.9291, 48.061191, 239.65969, false, true)
    FreezeEntityPosition(npc, true)
    SetEntityInvincible(npc, true)
    SetBlockingOfNonTemporaryEvents(npc, true)
    exports.ox_target:addLocalEntity(npc, options)
end)

Citizen.CreateThread(function()
    for Nikquz,v in pairs(FurtoVeh.GridVendita) do
        TriggerEvent('gridsystem:registerMarker', {
            name = 'menuvenditaveicolo',
            pos = vector3(1051.2613, -2460.871, 27.862623),
            size = v.size,
            scale = v.scale,
            color =  v.rgb,
            msg = 'VENDI VEICOLO',
            control = 'E',
            type = -1,
            texture = 'marker',
            action = function()
                if furto then
                    if IsPedInAnyVehicle(PlayerPedId(), false) then
                        local veh = GetDisplayNameFromVehicleModel(GetEntityModel(GetVehiclePedIsIn(PlayerPedId())))
                        for k, v in pairs(FurtoVeh.Macchine) do
                            for i, j in ipairs(v) do
                                local carname = veh:lower()
                                if j == carname then
                                    DeleteEntity(GetVehiclePedIsUsing(PlayerPedId()))
                                    TriggerServerEvent('nkz_vendita', k)
                                    RemoveBlip(vendita)
                                    RemoveBlip(blip)
                                    furto = false
                                end
                            end
                        end
                    end
                else
                    ESX.ShowNotification(NKZ_Traduzioni["no_macchine"])
                end
            end
        })
    end
end)

RegisterNetEvent('nkz_menufurtoveicolo')
AddEventHandler('nkz_menufurtoveicolo', function()
    staparlando = true
    Lavori = {
        {label = NKZ_Traduzioni["rischio_basso"], value = 'rischiobasso'},
        {label = NKZ_Traduzioni["rischio_medio"], value = 'rischiomedio'},
        {label = NKZ_Traduzioni["rischio_alto"], value = 'rischioalto'},
    }
    ESX.UI.Menu.Open('default', GetCurrentResourceName(), 'nkz', {
        title = NKZ_Traduzioni["title_furto"],
        align = FurtoVeh.MenuAlign,
        elements = Lavori
    },     function(data, menu)
            local bottone = data.current.value

            if bottone == 'rischiobasso' then
                staparlando = false
                TriggerEvent('dialogo_inizio_furto')
                menu.close()
                Citizen.Wait(15000)
                ESX.ShowNotification(NKZ_Traduzioni["appena_rintracciato_veicolo"])
                TriggerServerEvent('nkz_furtolivellobasso')
                menu.close()
            elseif bottone == 'rischiomedio' then
                staparlando = false
                TriggerEvent('dialogo_inizio_furto')
                menu.close()
                Citizen.Wait(15000)
                ESX.ShowNotification(NKZ_Traduzioni["appena_rintracciato_veicolo"])
                TriggerServerEvent('nkz_furtolivellomedio')
                menu.close()
            elseif bottone == 'rischioalto' then
                staparlando = false
                TriggerEvent('dialogo_inizio_furto')
                menu.close()
                Citizen.Wait(15000)
                ESX.ShowNotification(NKZ_Traduzioni["appena_rintracciato_veicolo"])
                TriggerServerEvent('nkz_furtolivelloalto')
                menu.close()
            end
        end, 
        function(data, menu)
               menu.close()
        end
    )
end)

RegisterCommand('ciao', function()
    TriggerEvent('nkz_menufurtoveicolo')
end)

RegisterNetEvent('nkz_blipvendita')
AddEventHandler('nkz_blipvendita', function()
    vendita = AddBlipForCoord(1051.2613, -2460.871, 27.862623)
    SetBlipSprite(vendita, FurtoVeh.BlipVendita)
    SetBlipColour(vendita, FurtoVeh.ColoreBlipVendita)
    SetBlipAsShortRange(vendita, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(NKZ_Traduzioni["vendita_blip"])
    EndTextCommandSetBlipName(vendita)
end)

RegisterNetEvent('nkz_blipfurto')
AddEventHandler('nkz_blipfurto', function()
    furto = true
    while furto do
        ESX.TriggerServerCallback("Coordinate", function(coordinate) 
            local blip = AddBlipForCoord(coordinate)
            SetBlipSprite(blip, FurtoVeh.BlipMacchinaRubataPerLSPD)
            SetBlipColour(blip, FurtoVeh.ColoreBlipMacchinaRubataPerLSPD)
            SetBlipAsShortRange(blip, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(NKZ_Traduzioni["nome_blip"])
            EndTextCommandSetBlipName(blip)
            SetBlipFlashTimer(blip, 120000)
            Citizen.Wait(10000)
            RemoveBlip(blip)
        end)
        Citizen.Wait(10000)
    end
    RemoveBlip(blip)
end)

RegisterNetEvent('nkz_blipcryptati')
AddEventHandler('nkz_blipcryptati', function()
    local blip1 = AddBlipForCoord(FurtoVeh.CoordinateCryptate[1])
    local blip2 = AddBlipForCoord(FurtoVeh.CoordinateCryptate[2])
    local blip3 = AddBlipForCoord(FurtoVeh.CoordinateCryptate[3])
    local blip4 = AddBlipForCoord(FurtoVeh.CoordinateCryptate[4])
    local blip5 = AddBlipForCoord(FurtoVeh.CoordinateCryptate[5])
    SetBlipSprite(blip1, FurtoVeh.BlipCryptatoMacchinaRubataPerLSPD)
    SetBlipColour(blip1, FurtoVeh.ColoreBlipCryptatoMacchinaRubataPerLSPD)
    SetBlipAsShortRange(blip1, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(NKZ_Traduzioni["nome_blip"])
    EndTextCommandSetBlipName(blip1)
    SetBlipSprite(blip2,  FurtoVeh.BlipCryptatoMacchinaRubataPerLSPD)
    SetBlipColour(blip2, FurtoVeh.ColoreBlipCryptatoMacchinaRubataPerLSPD)
    SetBlipAsShortRange(blip2, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(NKZ_Traduzioni["nome_blip"])
    EndTextCommandSetBlipName(blip2)
    SetBlipSprite(blip3,  FurtoVeh.BlipCryptatoMacchinaRubataPerLSPD)
    SetBlipColour(blip3, FurtoVeh.ColoreBlipCryptatoMacchinaRubataPerLSPD)
    SetBlipAsShortRange(blip3, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(NKZ_Traduzioni["nome_blip"])
    EndTextCommandSetBlipName(blip3)
    SetBlipSprite(blip4,  FurtoVeh.BlipCryptatoMacchinaRubataPerLSPD)
    SetBlipColour(blip4, FurtoVeh.ColoreBlipCryptatoMacchinaRubataPerLSPD)
    SetBlipAsShortRange(blip4, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(NKZ_Traduzioni["nome_blip"])
    EndTextCommandSetBlipName(blip4)
    SetBlipSprite(blip5,  FurtoVeh.BlipCryptatoMacchinaRubataPerLSPD)
    SetBlipColour(blip5, FurtoVeh.ColoreBlipCryptatoMacchinaRubataPerLSPD)
    SetBlipAsShortRange(blip5, true)
    BeginTextCommandSetBlipName('STRING')
    AddTextComponentSubstringPlayerName(NKZ_Traduzioni["nome_blip"])
    EndTextCommandSetBlipName(blip5)
    SetBlipFlashTimer(blip1, 120000)
    Citizen.Wait(1500)
    SetBlipFlashTimer(blip2, 120000)
    Citizen.Wait(2500)
    SetBlipFlashTimer(blip3, 120000)
    Citizen.Wait(3500)
    SetBlipFlashTimer(blip4, 120000)
    Citizen.Wait(4500)
    SetBlipFlashTimer(blip5, 120000)
    Citizen.Wait(FurtoVeh.TempoBlipCryptati)
    RemoveBlip(blip1)
    RemoveBlip(blip2)
    RemoveBlip(blip3)
    RemoveBlip(blip4)
    RemoveBlip(blip5)
end)

RegisterNetEvent('nkz_rischiobasso')
AddEventHandler('nkz_rischiobasso', function()
    local spawnveicolo = math.random(1, #FurtoVeh.Macchine.FasciaBassa)
    local vehiclerandom = FurtoVeh.Macchine.FasciaBassa[spawnveicolo]
    furto = true
    if spawnveicolo == 1 then
        if ESX.Game.IsSpawnPointClear(vector3(-3083.7099609375,219.42408752441,13.995937347412), 4.0) then
            waypoint = SetNewWaypoint(-3083.7099609375,219.42408752441)
            veicolo = CreateVehicle(vehiclerandom, -3083.7099609375,219.42408752441,13.995937347412, 325.0, true, false)
            SetVehicleDoorsLocked(veicolo, 2)
            SetVehicleEngineOn(veicolo, false, false, true)
            blipveicolo = AddBlipForCoord(-3083.7099609375,219.42408752441,13.995937347412)
            SetBlipSprite(blipveicolo, FurtoVeh.BlipAutoDaRubare)
            SetBlipColour(blipveicolo, FurtoVeh.ColoreBlipAutoDaRubare)
            SetBlipAsShortRange(blipveicolo, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(NKZ_Traduzioni["auto_da_rubare"])
            EndTextCommandSetBlipName(blipveicolo)
        else
            furto = false
            ESX.ShowNotification(NKZ_Traduzioni["soffiando_auto"])
        end
    elseif spawnveicolo == 2 then
        if ESX.Game.IsSpawnPointClear(vector3(-1.400496840477,6488.5693359375,31.505214691162), 4.0) then
            waypoint = SetNewWaypoint(-1.400496840477,6488.5693359375)
            veicolo = CreateVehicle(vehiclerandom, -1.400496840477,6488.5693359375,31.505214691162, 317.0, true, false)
            SetVehicleDoorsLocked(veicolo, 2)
            SetVehicleEngineOn(veicolo, false, false, true)
            blipveicolo = AddBlipForCoord(-1.400496840477,6488.5693359375,31.505214691162)
            SetBlipSprite(blipveicolo, FurtoVeh.BlipAutoDaRubare)
            SetBlipColour(blipveicolo, FurtoVeh.ColoreBlipAutoDaRubare)
            SetBlipAsShortRange(blipveicolo, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(NKZ_Traduzioni["auto_da_rubare"])
            EndTextCommandSetBlipName(blipveicolo)
        else
            furto = false
            ESX.ShowNotification(NKZ_Traduzioni["soffiando_auto"])
        end
    elseif spawnveicolo == 3 then
        if ESX.Game.IsSpawnPointClear(vector3(2887.4853515625,4380.3002929688,50.313091278076), 4.0) then
            waypoint = SetNewWaypoint(2887.4853515625,4380.3002929688)
            veicolo = CreateVehicle(vehiclerandom, 2887.4853515625,4380.3002929688,50.313091278076, 289.0, true, false)
            SetVehicleDoorsLocked(veicolo, 2)
            SetVehicleEngineOn(veicolo, false, false, true)
            blipveicolo = AddBlipForCoord(2887.4853515625,4380.3002929688,50.313091278076)
            SetBlipSprite(blipveicolo, FurtoVeh.BlipAutoDaRubare)
            SetBlipColour(blipveicolo, FurtoVeh.ColoreBlipAutoDaRubare)
            SetBlipAsShortRange(blipveicolo, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(NKZ_Traduzioni["auto_da_rubare"])
            EndTextCommandSetBlipName(blipveicolo)
        else
            furto = false
            ESX.ShowNotification(NKZ_Traduzioni["soffiando_auto"])
        end
    end
end)

RegisterNetEvent('nkz_rischiomedio')
AddEventHandler('nkz_rischiomedio', function()
    local spawnveicolo = math.random(1, #FurtoVeh.Macchine.FasciaMedia)
    local vehiclerandom = FurtoVeh.Macchine.FasciaMedia[spawnveicolo]
    furto = true
    if spawnveicolo == 1 then
        if ESX.Game.IsSpawnPointClear(vector3(6.1703462600708,-1760.2175292969,29.296922683716), 4.0) then
            waypoint = SetNewWaypoint(6.1703462600708,-1760.2175292969)
            veicolo = CreateVehicle(vehiclerandom, 6.1703462600708,-1760.2175292969,29.296922683716, 232.0, true, false)
            SetVehicleDoorsLocked(veicolo, 2)
            SetVehicleEngineOn(veicolo, false, false, true)
            blipveicolo = AddBlipForCoord(6.1703462600708,-1760.2175292969,29.296922683716)
            SetBlipSprite(blipveicolo, FurtoVeh.BlipAutoDaRubare)
            SetBlipColour(blipveicolo, FurtoVeh.ColoreBlipAutoDaRubare)
            SetBlipAsShortRange(blipveicolo, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(NKZ_Traduzioni["auto_da_rubare"])
            EndTextCommandSetBlipName(blipveicolo)
        else
            furto = false
            ESX.ShowNotification(NKZ_Traduzioni["soffiando_auto"])
        end
    elseif spawnveicolo == 2 then
        if ESX.Game.IsSpawnPointClear(vector3(490.47564697266,-1383.2490234375,29.34729385376), 4.0) then
            waypoint = SetNewWaypoint(490.47564697266,-1383.2490234375)
            veicolo = CreateVehicle(vehiclerandom, 490.47564697266,-1383.2490234375,29.34729385376, 175.0, true, false)
            SetVehicleDoorsLocked(veicolo, 2)
            SetVehicleEngineOn(veicolo, false, false, true)
            blipveicolo = AddBlipForCoord(490.47564697266,-1383.2490234375,29.34729385376)
            SetBlipSprite(blipveicolo, FurtoVeh.BlipAutoDaRubare)
            SetBlipColour(blipveicolo, FurtoVeh.ColoreBlipAutoDaRubare)
            SetBlipAsShortRange(blipveicolo, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(NKZ_Traduzioni["auto_da_rubare"])
            EndTextCommandSetBlipName(blipveicolo)
        else
            furto = false
            ESX.ShowNotification(NKZ_Traduzioni["soffiando_auto"])
        end
    elseif spawnveicolo == 3 then
        if ESX.Game.IsSpawnPointClear(vector3(450.04406738281,-558.43646240234,28.499795913696), 4.0) then
            waypoint = SetNewWaypoint(450.04406738281,-558.43646240234)
            veicolo = CreateVehicle(vehiclerandom, 450.04406738281,-558.43646240234,28.499795913696, 164.0, true, false)
            SetVehicleDoorsLocked(veicolo, 2)
            SetVehicleEngineOn(veicolo, false, false, true)
            blipveicolo = AddBlipForCoord(450.04406738281,-558.43646240234,28.499795913696)
            SetBlipSprite(blipveicolo, FurtoVeh.BlipAutoDaRubare)
            SetBlipColour(blipveicolo, FurtoVeh.ColoreBlipAutoDaRubare)
            SetBlipAsShortRange(blipveicolo, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(NKZ_Traduzioni["auto_da_rubare"])
            EndTextCommandSetBlipName(blipveicolo)
        else
            furto = false
            ESX.ShowNotification(NKZ_Traduzioni["soffiando_auto"])
        end
    end
end)

RegisterNetEvent('nkz_rischioalto')
AddEventHandler('nkz_rischioalto', function()
    local spawnveicolo = math.random(1, #FurtoVeh.Macchine.FasciaAlta)
    local vehiclerandom = FurtoVeh.Macchine.FasciaAlta[spawnveicolo]
    furto = true
    if spawnveicolo == 1 then
        if ESX.Game.IsSpawnPointClear(vector3(792.99078369141,1267.9600830078,360.29666137695), 4.0) then
            waypoint = SetNewWaypoint(792.99078369141,1267.9600830078)
            veicolo = CreateVehicle(vehiclerandom, 792.99078369141,1267.9600830078,360.29666137695, 320.0, true, false)
            SetVehicleDoorsLocked(veicolo, 2)
            SetVehicleEngineOn(veicolo, false, false, true)
            blipveicolo = AddBlipForCoord(792.99078369141,1267.9600830078,360.29666137695)
            SetBlipSprite(blipveicolo, FurtoVeh.BlipAutoDaRubare)
            SetBlipColour(blipveicolo, FurtoVeh.ColoreBlipAutoDaRubare)
            SetBlipAsShortRange(blipveicolo, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(NKZ_Traduzioni["auto_da_rubare"])
            EndTextCommandSetBlipName(blipveicolo)
        else
            furto = false
            ESX.ShowNotification(NKZ_Traduzioni["soffiando_auto"])
        end
    elseif spawnveicolo == 2 then
        if ESX.Game.IsSpawnPointClear(vector3(1731.3754882813,3310.1086425781,41.223503112793), 4.0) then
            waypoint = SetNewWaypoint(1731.3754882813,3310.1086425781)
            veicolo = CreateVehicle(vehiclerandom, 1731.3754882813,3310.1086425781,41.223503112793, 195.0, true, false)
            SetVehicleDoorsLocked(veicolo, 2)
            SetVehicleEngineOn(veicolo, false, false, true)
            blipveicolo = AddBlipForCoord(1731.3754882813,3310.1086425781,41.223503112793)
            SetBlipSprite(blipveicolo, FurtoVeh.BlipAutoDaRubare)
            SetBlipColour(blipveicolo, FurtoVeh.ColoreBlipAutoDaRubare)
            SetBlipAsShortRange(blipveicolo, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(NKZ_Traduzioni["auto_da_rubare"])
            EndTextCommandSetBlipName(blipveicolo)
        else
            furto = false
            ESX.ShowNotification(NKZ_Traduzioni["soffiando_auto"])
        end
    elseif spawnveicolo == 3 then
        if ESX.Game.IsSpawnPointClear(vector3(3333.7963867188,5161.5712890625,18.316471099854), 4.0) then
            waypoint = SetNewWaypoint(3333.7963867188,5161.5712890625)
            veicolo = CreateVehicle(vehiclerandom, 3333.7963867188,5161.5712890625,18.316471099854, 150.2, true, false)
            SetVehicleDoorsLocked(veicolo, 2)
            SetVehicleEngineOn(veicolo, false, false, true)
            blipveicolo = AddBlipForCoord(3333.7963867188,5161.5712890625,18.316471099854)
            SetBlipSprite(blipveicolo, FurtoVeh.BlipAutoDaRubare)
            SetBlipColour(blipveicolo, FurtoVeh.ColoreBlipAutoDaRubare)
            SetBlipAsShortRange(blipveicolo, true)
            BeginTextCommandSetBlipName('STRING')
            AddTextComponentSubstringPlayerName(NKZ_Traduzioni["auto_da_rubare"])
            EndTextCommandSetBlipName(blipveicolo)
        else
            furto = false
            ESX.ShowNotification(NKZ_Traduzioni["soffiando_auto"])
        end
    end
end)

RegisterNetEvent('nkz_dialogo')
AddEventHandler('nkz_dialogo', function()
    staparlando = true
    TaskPlayAnim(PlayerPedId(), "misscarsteal4@actor", "actor_berating_assistant", 1.0, -1.0, 8000, 0, 1, true, true, true)
    TaskPlayAnim(Nikquz, "oddjobs@assassinate@vice@hooker", "argue_a", 1.0, -1.0, 8000, 0, 1, true, true, true)
    NXN(NKZ_Traduzioni["parla_lester_1"])
    Citizen.Wait(3500)
    NXN(NKZ_Traduzioni["parla_lester_2"])
    staparlando = false
end)

RegisterNetEvent('dialogo2')
AddEventHandler('dialogo2', function()
    staparlando = true
    TaskPlayAnim(PlayerPedId(), "misscarsteal4@actor", "actor_berating_assistant", 1.0, -1.0, 8000, 0, 1, true, true, true)
    TaskPlayAnim(Nikquz, "oddjobs@assassinate@vice@hooker", "argue_a", 1.0, -1.0, 8000, 0, 1, true, true, true)
    Citizen.Wait(3500)
    NXN(NKZ_Traduzioni["no_auto_lester_1"])
    Citizen.Wait(3500)
    NXN(NKZ_Traduzioni["no_auto_lester_2"])
    staparlando = false
end)

RegisterNetEvent('dialogo_inizio_furto')
AddEventHandler('dialogo_inizio_furto', function()
    staparlando = true
    TaskPlayAnim(PlayerPedId(), "misscarsteal4@actor", "actor_berating_assistant", 1.0, -1.0, 3000, 0, 1, true, true, true)
    TaskPlayAnim(Nikquz, "oddjobs@assassinate@vice@hooker", "argue_a", 1.0, -1.0, 3000, 0, 1, true, true, true)
    NXN(NKZ_Traduzioni["dialogo_inizio_furto_lester_1"], 5000)
    Citizen.Wait(5000)
    NXN(NKZ_Traduzioni["attendi_rintraccia_veicolo"], 10000)
    Citizen.Wait(10000)
    NXN(NKZ_Traduzioni["dialogo_inizio_furto_lester_2"])
    staparlando = false
end)

RegisterNetEvent('nkz_grimaldello')
AddEventHandler('nkz_grimaldello', function()
    if FurtoVeh.rprogress then
        scassinando = true
        TaskPlayAnim(PlayerPedId(), "anim@amb@clubhouse@tutorial@bkr_tut_ig3@", "machinic_loop_mechandplayer", 1.0, -1.0, 20000, 0, 1, true, true, true)
        exports['rprogress']:Start('Scassinando...', 20000)
        ClearPedTasksImmediately(PlayerPedId())
        SetVehicleDoorsLocked(vehicle, 1)
        SetVehicleDoorsLockedForAllPlayers(vehicle, false)
        TriggerServerEvent('nkz_togligrimaldello')
        ESX.ShowNotification(NKZ_Traduzioni["veicolo_sbloccato"])
        TriggerServerEvent('nkz_bliperpolizia')
        TriggerEvent('nkz_blipvendita')
        waypoint = SetNewWaypoint(1051.2613, -2460.871, 27.862623)
        scassinando = false
    else
        scassinando = true
        TaskPlayAnim(PlayerPedId(), "anim@amb@clubhouse@tutorial@bkr_tut_ig3@", "machinic_loop_mechandplayer", 1.0, -1.0, 20000, 0, 1, true, true, true)
        Citizen.Wait(20000)
        ClearPedTasksImmediately(PlayerPedId())
        SetVehicleDoorsLocked(vehicle, 1)
        SetVehicleDoorsLockedForAllPlayers(vehicle, false)
        TriggerServerEvent('nkz_togligrimaldello')
        ESX.ShowNotification(NKZ_Traduzioni["veicolo_sbloccato"])
        scassinando = false
        TriggerServerEvent('nkz_bliperpolizia')
        TriggerEvent('nkz_blipvendita')
        waypoint = SetNewWaypoint(1051.2613, -2460.871, 27.862623)
    end
end)

RegisterNetEvent('nkz_scassina')
AddEventHandler('nkz_scassina', function()
    local playerped = PlayerPedId()
    local coords  = GetEntityCoords(playerped)
    vehicle = ESX.Game.GetVehicleInDirection()
    if IsAnyVehicleNearPoint(coords.x, coords.y, coords.z, 2.0) then
        if not scassinando then
            if furto then
                if FurtoVeh.rprogress then
                    exports.rprogress:MiniGame({
                        Difficulty = "Medium",
                        Timeout = 5000,
                        onComplete = function(success)
                            if success then
                                Citizen.Wait(2500)
                                TriggerEvent('nkz_grimaldello')
                                RemoveBlip(blipveicolo)
                                TriggerServerEvent('dispatchFURTO', 2)
                            else
                                local grimaldellorotto = math.random(1,5)
                                if grimaldellorotto == 1 then
                                    TriggerServerEvent('nkz_togligrimaldello')
                                    ESX.ShowNotification(NKZ_Traduzioni["grimaldello_rotto"])
                                elseif grimaldellorotto == 2 then
                                    ESX.ShowNotification(NKZ_Traduzioni["scassinamento_fallito"])
                                elseif grimaldellorotto == 3 then
                                    ESX.ShowNotification(NKZ_Traduzioni["scassinamento_fallito"])
                                elseif grimaldellorotto == 4 then
                                    ESX.ShowNotification(NKZ_Traduzioni["scassinamento_fallito"])
                                elseif grimaldellorotto == 5 then
                                    ESX.ShowNotification(NKZ_Traduzioni["scassinamento_fallito"])
                                end
                                TriggerServerEvent('dispatchFURTO', 2)
                            end
                        end,
                        onTimeout = function()
                            ESX.ShowNotification(NKZ_Traduzioni["tempo_scassinamento"])
                            TriggerServerEvent('dispatchFURTO', 2)
                        end
                    })
                else
                    TriggerEvent('nkz_grimaldello')
                    RemoveBlip(blipveicolo)
                end
            else
                ESX.ShowNotification(NKZ_Traduzioni["no_azione_ora"])
            end
        else
            ESX.ShowNotification(NKZ_Traduzioni["già_scassinando"])
        end
    else
        ESX.ShowNotification(NKZ_Traduzioni["no_veicoli_vicini"])
    end
end)

RegisterNetEvent('nkz_voltlab')
AddEventHandler('nkz_voltlab', function()
    ped = PlayerPedId()
    local vehicle = GetVehiclePedIsIn(ped, false)
    if IsPedInVehicle(ped, vehicle, false) then
        if not scassinando then
            if furto then
                if FurtoVeh.voltlab then
                    scassinando = true
                    TriggerEvent('ultra-voltlab', 35, function(result,reason)
                        if result == 0 then
                            ESX.ShowNotification(NKZ_Traduzioni["scassinamento_fallito"])
                        elseif result == 1 then
                            SetVehicleEngineOn(vehicle, true, true, false)
                            ESX.ShowNotification(NKZ_Traduzioni["sistema_hack"])
                            TriggerServerEvent('nkz_bliperpolizia')
                            TriggerEvent('nkz_blipvendita')
                            waypoint = SetNewWaypoint(1051.2613, -2460.871, 27.862623)
                        elseif result == 2 then
                            ESX.ShowNotification(NKZ_Traduzioni["tempo_scaduto"])
                        end
                        scassinando= false
                    end)
                elseif FurtoVeh.rprogress then
                    exports['rprogress']:Start('Hackerando...', 20000)
                    SetVehicleEngineOn(vehicle, true, true, false)
                    ESX.ShowNotification(NKZ_Traduzioni["sistema_hack"])
                    TriggerServerEvent('nkz_bliperpolizia')
                    TriggerEvent('nkz_blipvendita')
                    waypoint = SetNewWaypoint(1051.2613, -2460.871, 27.862623)
                else
                    SetVehicleEngineOn(vehicle, true, true, false)
                    ESX.ShowNotification(NKZ_Traduzioni["sistema_hack"])
                    TriggerServerEvent('nkz_bliperpolizia')
                    TriggerEvent('nkz_blipvendita')
                    waypoint = SetNewWaypoint(1051.2613, -2460.871, 27.862623)
                end
            else
                ESX.ShowNotification(NKZ_Traduzioni["no_azione_ora"])
            end
        end
    else
        ESX.ShowNotification(NKZ_Traduzioni["interno_veicolo"])
    end
end)
