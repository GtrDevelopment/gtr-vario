local holdingUp = false
local store = ""
local blipRobbery = nil

ESX = exports.es_extended:getSharedObject()


function drawTxt(x,y, width, height, scale, text, r,g,b,a, outline)
	SetTextFont(0)
	SetTextScale(scale, scale)
	SetTextColour(r, g, b, a)
	SetTextDropshadow(0, 0, 0, 0,255)
	SetTextDropShadow()
	if outline then SetTextOutline() end

	BeginTextCommandDisplayText('STRING')
	AddTextComponentSubstringPlayerName(text)
	EndTextCommandDisplayText(x - width/2, y - height/2 + 0.005)
end




RegisterNetEvent('gtr_rapine:currentlyRobbing')
AddEventHandler('gtr_rapine:currentlyRobbing', function(currentStore)
	holdingUp, store = true, currentStore
end)



RegisterNetEvent('gtr_rapine:killBlip')
AddEventHandler('gtr_rapine:killBlip', function()
	RemoveBlip(blipRobbery)
end)



RegisterNetEvent('gtr_rapine:setBlip')
AddEventHandler('gtr_rapine:setBlip', function(position)
	blipRobbery = AddBlipForCoord(position.x, position.y, position.z)

	SetBlipSprite(blipRobbery, 161)
	SetBlipScale(blipRobbery, 0.6)
	SetBlipColour(blipRobbery, 1)

	PulseBlip(blipRobbery)
end)



RegisterNetEvent('gtr_rapine:tooFar')
AddEventHandler('gtr_rapine:tooFar', function()
	holdingUp, store = false, ''
	ESX.ShowNotification('Rapina anullata')
end)



RegisterNetEvent('gtr_rapine:robberyComplete')
AddEventHandler('gtr_rapine:robberyComplete', function(award)
	holdingUp, store = false, ''
	ESX.ShowNotification('Rapina conclusa, soldi guadagnati: '..award)
end)



RegisterNetEvent('gtr_rapine:startTimer')
AddEventHandler('gtr_rapine:startTimer', function()
	local timer = GTR.Stores[store].secondsRemaining

	Citizen.CreateThread(function()
		while timer > 0 and holdingUp do
			Citizen.Wait(1000)

			if timer > 0 then
				timer = timer - 1
			end
		end
	end)

	Citizen.CreateThread(function()
		while holdingUp do
			Citizen.Wait(3)
			drawTxt(0.90, 1.44, 1.0, 1.0, 0.4, 'Rapina in corso: ' ..timer.. ' secondi rimanenti', 255, 255, 255, 255)
		end
	end)
end)




Citizen.CreateThread(function()
	Wait(2000)
	for k,v in pairs(GTR.Stores) do
		local blip = AddBlipForCoord(v.position.x, v.position.y, v.position.z)
		SetBlipSprite(blip, 110)
		SetBlipScale(blip, 0.5)
		SetBlipColour(blip, 1)
		SetBlipAsShortRange(blip, true)

		BeginTextCommandSetBlipName("STRING")
		AddTextComponentString('Rapina')
		EndTextCommandSetBlipName(blip)
	end
end)


Citizen.CreateThread(function()
    Wait(4000)
    for k,v in pairs(GTR.Stores) do
        local storePos = v.position 
        TriggerEvent('gridsystem:registerMarker', {
            name = 'rapina'..storePos.x,
            pos = vector3(storePos.x, storePos.y, storePos.z),
            scale = vector3(1.0, 1.0, 1.0),
            size = vector3(1.0,1.0,1.0),
            drawDistance = 5.0,
            msg = 'Premi [E] - per iniziare la rapina alla '..v.nameOfStore,
            control = 'E',
            color = {r = 255, g = 255, b = 255},
            type = 29,
            action = function()
                if IsPedArmed(PlayerPedId(), 4) then
                    ESX.TriggerServerCallback('gepoliceplayers', function(police) 
                        if police >= v.poliziotti then
                            local success = lib.skillCheck({'easy', 'easy', {areaSize = 60, speedMultiplier = 2}, 'easy'}, {'w', 'a', 's', 'd'})

                            if success then
                                local coordinateallapula = GetEntityCoords(PlayerPedId())
                                TriggerServerEvent('gtr_rapine:robberyStarted', k, v.poliziotti, ESX.PlayerData.job)
                                TriggerServerEvent('notificaspolice')
							end
                        else
                            ESX.ShowNotification('Non ci sono abbastanza poliziotti')
                        end
                    end)
                else
                    ESX.ShowNotification('Bro, con cosa pensi di fare una rapina, con le mani?')
                end
            end
        })
    end
end)




Citizen.CreateThread(function()
	while true do
		local playerPos = GetEntityCoords(PlayerPedId(), true)
		if holdingUp then
			local storePos = GTR.Stores[store].position
			if Vdist(playerPos.x, playerPos.y, playerPos.z, storePos.x, storePos.y, storePos.z) > GTR.MaxDistance then
				TriggerServerEvent('gtr_rapine:tooFar', store)
			end
		end
		Citizen.Wait(1000)
	end
end)

