local carry = {
	InProgress = false,
	targetSrc = -1,
	type = "",
	personCarrying = {
		animDict = "missfinale_c2mcs_1",
		anim = "fin_c2_mcs_1_camman",
		flag = 49,
	},
	personCarried = {
		animDict = "nm",
		anim = "firemans_carry",
		attachX = 0.27,
		attachY = 0.15,
		attachZ = 0.63,
		flag = 33,
	}
}

exports('IsInCarry', function()
	return carry.InProgress
end)

local function drawNativeNotification(text, type)
	TriggerEvent('esx:showNotification', text, type)
end

local function GetClosestPlayer(radius)
    local players = GetActivePlayers()
    local closestDistance = -1
    local closestPlayer = -1
    local playerPed = cache.ped
    local playerCoords = GetEntityCoords(playerPed)
    for _,playerId in ipairs(players) do
        local targetPed = GetPlayerPed(playerId)
        if targetPed ~= playerPed then
            local targetCoords = GetEntityCoords(targetPed)
            local distance = #(targetCoords-playerCoords)
            if closestDistance == -1 or closestDistance > distance then
                closestPlayer = playerId
                closestDistance = distance
            end
        end
    end
	if closestDistance ~= -1 and closestDistance <= radius then
		return closestPlayer
	else
		return nil
	end
end

local function ensureAnimDict(animDict)
    if not HasAnimDictLoaded(animDict) then
        RequestAnimDict(animDict)
        while not HasAnimDictLoaded(animDict) do
            Wait(0)
        end        
    end
    return animDict
end


--[[local inattesarisposta = false
local attendendorisposta = false

RegisterNetEvent('vario:richiestaaggiornata', function (bool)
	inattesarisposta = bool
	if bool == false then 
		exports['okokTextUI']:Close()
	end
end)

RegisterNetEvent('vario:inoltrarichiesta', function(chimanda)
	inattesarisposta = true
	exports['okokTextUI']:Open('Un giocatore vuole prenderti in spalla.\nPremi [E] per ACCETTARE, [N] per RIFIUTARE.', 'darkgreen', 'right')
	while inattesarisposta do
		Citizen.Wait(0)
		-- ESX.ShowHelpNotification('Un giocatore vuole prenderti in spalla.\nPremi [E] per ACCETTARE, [N] per RIFIUTARE.')
		if IsControlJustPressed(1, 86) then -- E 
            inattesarisposta = false
			TriggerServerEvent('vario:carryrisposto', true, chimanda)
			exports['okokTextUI']:Close()
        elseif IsControlJustPressed(1,306) then --N 
            inattesarisposta = false
			TriggerServerEvent('vario:carryrisposto', false, chimanda)
			exports['okokTextUI']:Close()
        end
	end
end)

RegisterNetEvent('vario:finalmenteloprendiamoinspalla', function(target)
	local targetSrc = target
	if attendendorisposta then
		attendendorisposta = false
		tempoattesa = 0
		ESX.ShowNotification('La tua richiesta di prendere in spalla il giocatore è stata accettata.')
		carry.InProgress = true
		InitCarry()
		carry.targetSrc = targetSrc
		TriggerServerEvent("CarryPeople:sync",targetSrc)
		ensureAnimDict(carry.personCarrying.animDict)
		carry.type = "carrying"
	end
end)

RegisterNetEvent('vario:ennientefratelli', function (bool)
	attendendorisposta = bool
end)

function checkarisposta(target)
	if attendendorisposta then
		attendendorisposta = false
		ESX.ShowNotification('Richiesta rifiutata automaticamente.')
		TriggerServerEvent('vario:aggiornarichiesta', target, false)
	end
end]]

RegisterCommand("spalla",function(source, args)
	local pcoords = GetEntityCoords(PlayerPedId())

	if exports["vario"]:IsInBarbie() then
		return
	end

	local distanzadaospedale = GetDistanceBetweenCoords(-813.9238, -1230.4810, 7.3375, pcoords.x, pcoords.y, pcoords.z, true) 
	-- if exports['vario']:DentroIlNegro() and distanzadaospedale > 15 then
	-- 	ESX.ShowNotification('Non puoi farlo in zona safe!')
	-- 	return
	-- end
	-- if not CanPlayerInteract(true) then
	-- 	print('[DEBUG] Azione Impossibile')
	-- 	return
	-- end

	if not carry.InProgress then
		local closestPlayer = GetClosestPlayer(3)
		if closestPlayer then
			local targetSrc = GetPlayerServerId(closestPlayer)
			if targetSrc ~= -1 then
				--[[TriggerServerEvent('vario:richiedispalla', targetSrc)
				ESX.ShowNotification('La tua richiesta di prendere in spalla il giocatore è stata inoltrata.')
				attendendorisposta = true
				Citizen.Wait(5000)
				checkarisposta(targetSrc)
				tempoattesa = 5]]
				carry.InProgress = true
				InitCarry()
				carry.targetSrc = targetSrc
				TriggerServerEvent("CarryPeople:sync",targetSrc)
				ensureAnimDict(carry.personCarrying.animDict)
				carry.type = "carrying"
			else
                ESX.ShowNotification('Nessuno da prendere')
			end
		else
			ESX.ShowNotification('Nessuno da prendere') --ESX.ShowNotification('Nessuno da prendere')
		end
	else
		carry.InProgress = false
		ClearPedSecondaryTask(cache.ped)
		DetachEntity(cache.ped, true, false)
		TriggerServerEvent("CarryPeople:stop",carry.targetSrc)
		carry.targetSrc = 0
	end
end, false)


RegisterNetEvent("CarryPeople:syncTarget")
AddEventHandler("CarryPeople:syncTarget", function(targetSrc)
	local targetPed = GetPlayerPed(GetPlayerFromServerId(targetSrc))
	carry.InProgress = true
	InitCarry()
	ensureAnimDict(carry.personCarried.animDict)
	AttachEntityToEntity(cache.ped, targetPed, 0, carry.personCarried.attachX, carry.personCarried.attachY, carry.personCarried.attachZ, 0.5, 0.5, 180, false, false, false, false, 2, false)
	carry.type = "beingcarried"
end)

RegisterNetEvent("CarryPeople:cl_stop")
AddEventHandler("CarryPeople:cl_stop", function()
	carry.InProgress = false
	ClearPedSecondaryTask(cache.ped)
	DetachEntity(cache.ped, true, false)
end)

exports("PresoCarry", function ()
	return carry.type and carry.type == "beingcarried"
end)

function InitCarry()
	Citizen.CreateThread(function()
		while true do
			if carry.InProgress then
				if carry.type == "beingcarried" then
					if not IsEntityPlayingAnim(cache.ped, carry.personCarried.animDict, carry.personCarried.anim, 3) then
						TaskPlayAnim(cache.ped, carry.personCarried.animDict, carry.personCarried.anim, 8.0, -8.0, 100000, carry.personCarried.flag, 0, false, false, false)
					end
				elseif carry.type == "carrying" then
					if not IsEntityPlayingAnim(cache.ped, carry.personCarrying.animDict, carry.personCarrying.anim, 3) then
						TaskPlayAnim(cache.ped, carry.personCarrying.animDict, carry.personCarrying.anim, 8.0, -8.0, 100000, carry.personCarrying.flag, 0, false, false, false)
					end
				end
			else
				return
			end
			Citizen.Wait(5)
		end
	end)
end