RegisterNetEvent('vario:UsaBenda', function()
    local lib, anim = 'anim@heists@narcotics@funding@gang_idle', 'gang_chatting_idle01' -- TODO better animations

    exports.rprogress:Custom({
        Async = false,
        canCancel = true,       -- Allow cancelling
        cancelKey = 73,        -- Custom cancel key
        Duration = 7000,        -- Duration of the progress
        ShowTimer = true,       -- Shows the timer countdown within the radial dial
        Label = "Usando la benda...",
        Animation = {
            animationDictionary = lib, -- https://alexguirre.github.io/animations-list/
            animationName = anim,
        },
        DisableControls = {
            Mouse = false,
            Player = true,
            Vehicle = true
        },    
        onComplete = function(cancelled)
            if not cancelled then
                ESX.TriggerServerCallback('vario:TogliBenda', function(cn)
                    if cn then
                        local playerPed = cache.ped
                        local maxHealth = GetEntityMaxHealth(playerPed)
        
                        local health = GetEntityHealth(playerPed)
                        local newHealth = math.min(maxHealth, math.floor(health + maxHealth / 10))
                        SetEntityHealth(playerPed, newHealth)
                        ESX.ShowNotification('Hai usato una benda!')
                    end
                end)
            end
        end
    })
end)

RegisterNetEvent('vario:UsaMedikit', function()
    local lib, anim = 'anim@heists@narcotics@funding@gang_idle', 'gang_chatting_idle01' -- TODO better animations

    exports.rprogress:Custom({
        Async = false,
        canCancel = true,       -- Allow cancelling
        cancelKey = 73,        -- Custom cancel key
        Duration = 10000,        -- Duration of the progress
        ShowTimer = true,       -- Shows the timer countdown within the radial dial
        Label = "Usando il medikit...",
        Animation = {
            animationDictionary = lib, -- https://alexguirre.github.io/animations-list/
            animationName = anim,
        },
        DisableControls = {
            Mouse = false,
            Player = true,
            Vehicle = true
        },    
        onComplete = function(cancelled)
            if not cancelled then
                ESX.TriggerServerCallback('vario:TogliMedikit', function(cn)
                    if cn then
                        local playerPed = cache.ped
                        local maxHealth = GetEntityMaxHealth(playerPed)

                        SetEntityHealth(playerPed, maxHealth)
                        ESX.ShowNotification('Hai usato un medikit!')
                    end
                end)
            end
        end
    })
end)