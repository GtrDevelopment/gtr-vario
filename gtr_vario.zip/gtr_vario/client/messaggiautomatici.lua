local Messaggi = {
    "Ciao caro! noi stiamo usando la chat vocale! se hai problemi recati in ass! Uno staff ti aiutera a settarla!"
}

local Attuale = 1
CreateThread(function()
    while true do
        TriggerEvent('chat:addMessage', {
            template = '<div class="chat-message system"><i class="fas fa-cog"></i> <b><span style="color: #e1e1e1">GTR</span>&nbsp;<span style="font-size: 14px; color: #e1e1e1;">{0}</span></b><div style="margin-top: 5px; font-weight: 300;"><b>{1}</b></div></div>',
            args = {"00:00", Messaggi[Attuale]}
        })
        Attuale += 1
        if Attuale > #Messaggi then Attuale = 1 end
        Wait(4 * 60 * 1000)
    end
end)