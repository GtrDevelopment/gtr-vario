local Lavorando = false

Citizen.CreateThread(function()
    for k, v in pairs(Droghe.BlipRaccolta) do
        TriggerEvent('gridsystem:registerMarker', {
            name = 'el_smallresources_droghe_raccolta_'..k,
            pos = v.Pos,
            scale = vector3(1.3, 1.3, 1.3),
            size = vector3(3.0, 3.0, 3.0),
            msg = 'Premi [E] per raccogliere',
            control = 'E',
            type = -1,
            texture = 'bombarp',
            shouldBob = false,
            shouldRotate = false,
            drawDistance = 5.0,
            permission = v.reqJob,
            color = { r = 255, g = 255, b = 255 },
            action = function()
                if not Lavorando then
                    Raccogli(v, k)
                end
            end
        })
    end

    for k, v in pairs(Droghe.BlipProcesso) do
        local jobReq, gradeReq = nil, nil
        if v.reqJob then
             jobReq = v.reqJob.name
             gradeReq = v.reqJob.grade
        end
        TriggerEvent('gridsystem:registerMarker', {
            name = 'el_smallresources_droghe_processo_'..k,
            pos = v.Pos,
            scale = vector3(1.3, 1.3, 1.3),
            size = vector3(3.0, 3.0, 3.0),
            msg = 'Premi [E] per processare',
            control = 'E',
            type = -1,
            texture = 'bombarp',
            shouldBob = false,
            shouldRotate = false,
            drawDistance = 5.0,
            permission = jobReq,
            jobGrade = gradeReq,
            color = { r = 255, g = 255, b = 255 },
            action = function()
                if not Lavorando then
                    Processo(v, k)
                end
            end
        })
    end
end)

function Raccogli(data, index)
    --local playerPed = cache.ped
    --TaskStartScenarioInPlace(playerPed, 'world_human_gardener_plant', 0, false)
    if not cache.vehicle then
        Lavorando = true
        exports.rprogress:Custom({
            Async = true,
            canCancel = true,       -- Allow cancelling
            cancelKey = 73,        -- Custom cancel key
            x = 0.5,                -- Position on x-axis
            y = 0.5,                -- Position on y-axis
            Duration = 20000,        -- Duration of the progress
            Label = "Raccogliendo...",
            Animation = {
                scenario = "world_human_gardener_plant", -- https://pastebin.com/6mrYTdQv
            },
            DisableControls = {
                Mouse = false,
                Player = true,
                Vehicle = true
            },
            onComplete = function(cancelled)
                Lavorando = false
                if not cancelled then
                    TriggerServerEvent('el_smallresources:DaiDroga', data, index)
                end
            end
        })

        Wait(20000)
        Lavorando = false
    end
end

--[[RegisterNetEvent('steffone:droghe:IniziaEffetti', function()
    exports.rprogress:Custom({
        Async = true,
        canCancel = true,       -- Allow cancelling
        cancelKey = 73,        -- Custom cancel key
        x = 0.5,                -- Position on x-axis
        y = 0.5,                -- Position on y-axis
        Duration = 10000,        -- Duration of the progress
        Label = "Fumando...",
        Animation = {
            scenario = "WORLD_HUMAN_SMOKING_POT",
        },
        DisableControls = {
            Mouse = false,
            Player = true,
            Vehicle = true
        },
        onComplete = function(cancelled)
            ClearPedTasks(cache.ped)
            if not cancelled then
                DoAcid(120000)
            end
        end
    })
end)]]--

function Processo(data, index)
    if not cache.vehicle then
        Lavorando = true
        local reqTime = data.time or 10000
        exports.rprogress:Custom({
            Async = true,
            canCancel = true,       -- Allow cancelling
            cancelKey = 73,        -- Custom cancel key
            x = 0.5,                -- Position on x-axis
            y = 0.5,                -- Position on y-axis
            Duration = reqTime,        -- Duration of the progress
            Label = "Processando...",
            Animation = {
                animationDictionary = "anim@amb@business@weed@weed_inspecting_lo_med_hi@", -- https://alexguirre.github.io/animations-list/
                animationName = "weed_crouch_checkingleaves_idle_03_inspector",
            },
            DisableControls = {
                Mouse = false,
                Player = true,
                Vehicle = true
            },
            onComplete = function(cancelled)
                Lavorando = false
                if not cancelled then
                    TriggerServerEvent('el_smallresources:ProcessoDroga', data, index)
                end
            end
        })

        Wait(reqTime)
        Lavorando = false
    end
end