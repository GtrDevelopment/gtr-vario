
Slashme = {
    color = { r = 230, g = 230, b = 230, a = 255 }, -- Text color
    font = 0, -- Text font
    time = 6000, -- Duration to display the text (in ms)
    scale = 0.5, -- Text scale
    dist = 250, -- Min. distance to draw 
}



local c = Slashme -- Pre-load the config
local peds = {}
-- Localization
local GetGameTimer = GetGameTimer
local function draw3dText(coords, text)
    local camCoords = GetGameplayCamCoord()
    local dist = #(coords - camCoords)
    
    -- Experimental math to scale the text down
    local scale = 200 / (GetGameplayCamFov() * dist)
    -- Format the text
    SetTextColour(c.color.r, c.color.g, c.color.b, c.color.a)
    SetTextScale(0.0, c.scale * scale)
    SetTextFont(c.font)
    SetTextDropshadow(0, 0, 0, 0, 55)
    SetTextDropShadow()
    SetTextCentre(true)
    -- Diplay the text
    BeginTextCommandDisplayText("STRING")
    AddTextComponentSubstringPlayerName(text)
    SetDrawOrigin(coords, 0)
    EndTextCommandDisplayText(0.0, 0.0)
    ClearDrawOrigin()
end

local function displayText(ped, text)
    print('a')
    local playerPed = PlayerPedId()
    local playerPos = GetEntityCoords(playerPed)
    local targetPos = GetEntityCoords(ped)
    local dist = #(playerPos - targetPos)
    local los = HasEntityClearLosToEntity(playerPed, ped, 17)
    if dist <= c.dist and los then
        local exists = peds[ped] ~= nil
        peds[ped] = {
            time = GetGameTimer() + c.time,
            text = text
        }
        if not exists then
            local display = true
            while display do
                Wait(0)
                local pos = GetOffsetFromEntityInWorldCoords(ped, 0.0, 0.0, 1.0)
                draw3dText(pos, peds[ped].text)
                display = GetGameTimer() <= peds[ped].time
            end
            peds[ped] = nil
        end
    end
end



local function onShareDisplay(text, target)
    local player = GetPlayerFromServerId(target)
    if player ~= -1 or target == GetPlayerServerId(PlayerId()) then
        local ped = GetPlayerPed(player)
        displayText(ped, text)
    end
end

RegisterNetEvent('3dme:shareDisplay', onShareDisplay)



function AltrooMinutiOra()
    if ora <= 9 then
        ora = "0" .. ora
    end
    if minutoo <= 9 then
        minutoo = "0" .. minutoo
    end
    if ora == 24 then
        ora =  "00"
    end
end

Citizen.CreateThread(function()
    while true do
        Wait(0)
        anno, mese, giorno, ora, minutoo = GetLocalTime()
        ora = ora + 0
        AltrooMinutiOra()
        
        SetTextFont(4)
        SetTextScale(0.39, 0.39)
        SetTextWrap(0.0, 1.0)
        SetTextCentre(false)
        SetTextDropshadow(2, 2, 0, 0, 0)
        SetTextEdge(1, 0, 0, 0, 205)
        SetTextOutline()
        SetTextEntry("STRING")
        
        AddTextComponentString(giorno .. "/" .. mese .. "/" .. anno .. " | " .. ora .. ":" .. minutoo)
        DrawText(0.475, 0.001)
    end
end)

-- CreateThread(function()
--     for i = 1, 4 do
--         ExecuteCommand('me Appena ~y~Arrivato')
--         Wait(5000)
--     end
-- end)
