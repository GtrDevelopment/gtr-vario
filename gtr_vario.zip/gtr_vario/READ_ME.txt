per far funzionare il vario non rinominate niente

poi create una cartella in questo modo [vario]

poi nel cfg fate ensure [vario]

E poi andra qualsiasi problema entrate nel discord 
https://discord.gg/S26hHWP799

To make the vario work, don't rename anything

then create a folder like this [miscellaneous]

then in the cfg do ensure [various]

And then any problem will be solved, enter the discord
https://discord.gg/S26hHWP799